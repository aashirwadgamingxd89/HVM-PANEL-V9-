function requireAuth(req, res, next) {
  if (!req.session.userId) return res.redirect('/auth/login');
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  if (!user) { req.session.destroy(); return res.redirect('/auth/login'); }
  // Block suspended users from everything except logout
  if (user.status === 'suspended' && !req.path.includes('/auth/')) {
    req.session.destroy();
    return res.redirect('/auth/login?suspended=1');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.userId) return res.redirect('/auth/login');
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  if (!user || user.role !== 'admin') {
    return res.status(403).render('error', {
      title: 'Access Denied',
      message: 'You do not have permission to access this area.',
      settings: req.app.get('db').getSettings(), user: null, unreadCount: 0
    });
  }
  if (user.status === 'suspended') { req.session.destroy(); return res.redirect('/auth/login?suspended=1'); }
  next();
}

function requireServerAccess(req, res, next) {
  if (!req.session.userId) return res.redirect('/auth/login');
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  if (!user) return res.redirect('/auth/login');
  if (user.status === 'suspended') { req.session.destroy(); return res.redirect('/auth/login?suspended=1'); }

  const server = db.getServerById(req.params.id);
  if (!server) return res.status(404).render('error', {
    title: 'Not Found', message: 'Server not found.',
    settings: db.getSettings(), user, unreadCount: db.getUnreadCount(user.id)
  });

  if (user.role === 'admin' || server.ownerId === user.id) {
    req.server = server; req.isOwner = true; return next();
  }
  const sub = db.getSubusersByServer(server.id).find(s => s.userId === user.id);
  if (sub) { req.server = server; req.isOwner = false; req.subuser = sub; return next(); }

  res.status(403).render('error', {
    title: 'Access Denied', message: 'You do not have access to this server.',
    settings: db.getSettings(), user, unreadCount: db.getUnreadCount(user.id)
  });
}

module.exports = { requireAuth, requireAdmin, requireServerAccess };
