const { exec } = require('child_process');

// Install localtunnel if needed, then start tunnel
exec('npx localtunnel --port 3000', (err, stdout, stderr) => {});

const lt = require('child_process').spawn('npx', ['localtunnel', '--port', '3000'], { stdio: 'pipe' });

lt.stdout.on('data', (data) => {
  const out = data.toString();
  console.log(out);
  const match = out.match(/https:\/\/[a-z0-9-]+\.loca\.lt/);
  if (match) {
    console.log('\n========================================');
    console.log('  YOUR PUBLIC URL: ' + match[0]);
    console.log('========================================\n');
  }
});

lt.stderr.on('data', (data) => console.error(data.toString()));
