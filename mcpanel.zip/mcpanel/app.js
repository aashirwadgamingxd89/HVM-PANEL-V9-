const express = require('express');
const session = require('express-session');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const db = require('./lib/db');
const multer = require('multer');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'mcpanel-vantixnodes-secret-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

app.set('db', db);
app.set('io', io);

// Global middleware
app.use(async (req, res, next) => {
  res.locals.user = null;
  res.locals.settings = db.getSettings();
  res.locals.unreadCount = 0;
  if (req.session.userId) {
    const user = db.getUserById(req.session.userId);
    if (user) {
      // Suspended users can only access logout
      if (user.status === 'suspended' && !req.path.startsWith('/auth')) {
        return res.render('suspended', { title: 'Account Suspended', settings: res.locals.settings, user });
      }
      res.locals.user = user;
      res.locals.unreadCount = db.getUnreadCount(user.id);
    }
  }
  next();
});

// Routes
app.use('/auth', require('./routes/auth'));
app.use('/dashboard', require('./routes/dashboard'));
app.use('/servers', require('./routes/servers'));
app.use('/admin', require('./routes/admin'));
app.use('/api', require('./routes/api'));
app.use('/profile', require('./routes/profile'));
app.use('/notifications', require('./routes/notifications'));

app.get('/', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.redirect('/auth/login');
});

// Socket.IO
require('./lib/socket')(io, db);

// Init Firebase then DB
async function start() {
  try {
    const { initFirebase, getDb } = require('./lib/firebase');
    await initFirebase();
    const fbDb = getDb();
    if (fbDb) db.setFirebaseDb(fbDb);
  } catch(e) {
    console.warn('Firebase skipped:', e.message);
  }

  await db.init();

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 VantixNodes Panel running at http://localhost:${PORT}`);
  });
}

start();
