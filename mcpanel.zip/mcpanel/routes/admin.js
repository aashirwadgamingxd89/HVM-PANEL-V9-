const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const multer = require('multer');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 }
});

router.get('/', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const users = db.getUsers();
  const servers = db.getServers();
  res.render('admin/index', {
    title: 'Admin Overview', context: 'admin',
    users: users.slice(-5).reverse(),
    servers: servers.slice(-5).reverse(),
    stats: {
      totalUsers: users.length, totalServers: servers.length,
      runningServers: servers.filter(s => s.status === 'online').length,
      totalPlayers: servers.reduce((sum, s) => sum + (s.players || 0), 0)
    }
  });
});

// Users
router.get('/users', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const q = req.query.q || '';
  let users = db.getUsers();
  if (q) users = users.filter(u => u.username.includes(q) || u.email.includes(q));
  res.render('admin/users', { title: 'User Management', context: 'admin', users, q });
});

router.get('/users/create', requireAdmin, (req, res) => {
  res.render('admin/user-form', { title: 'Create User', context: 'admin', user: null, error: null });
});

router.post('/users/create', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { username, email, password, role, status, maxServers } = req.body;
  if (db.getUserByUsername(username)) {
    return res.render('admin/user-form', { title: 'Create User', context: 'admin', user: null, error: 'Username already taken.' });
  }
  db.createUser({ username, email, password, role, status, maxServers: parseInt(maxServers) || 5 });
  res.redirect('/admin/users');
});

router.get('/users/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const user = db.getUserById(req.params.id);
  if (!user) return res.redirect('/admin/users');
  res.render('admin/user-form', { title: 'Edit User', context: 'admin', user, error: null });
});

router.post('/users/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { username, email, password, role, status, maxServers } = req.body;
  const data = { username, email, role, status, maxServers: parseInt(maxServers) || 5 };
  if (password) data.password = password;
  db.updateUser(req.params.id, data);
  // If suspending a user, their session will block on next request
  res.redirect('/admin/users');
});

router.post('/users/:id/delete', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  if (req.params.id !== req.session.userId) db.deleteUser(req.params.id);
  res.redirect('/admin/users');
});

// Servers
router.get('/servers', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const q = req.query.q || '';
  let servers = db.getServers().map(s => ({ ...s, owner: db.getUserById(s.ownerId) }));
  if (q) servers = servers.filter(s => s.name.includes(q) || (s.owner && s.owner.username.includes(q)));
  res.render('admin/servers', { title: 'Server Management', context: 'admin', servers, q });
});

router.get('/servers/create', requireAdmin, (req, res) => {
  res.render('admin/server-form', { title: 'Create Server', context: 'admin', server: null, users: req.app.get('db').getUsers(), error: null });
});

router.post('/servers/create', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { name, ownerId, type, version, port, ram, javaArgs } = req.body;
  const server = db.createServer({ name, ownerId, type, version, port: parseInt(port), ram: parseInt(ram), javaArgs });
  // Auto-install playit plugin entry
  db.updateServer(server.id, { playitInstalled: true });
  db.createNotification(ownerId, {
    type: 'success', title: 'Server Created',
    message: `Your server "${name}" is ready. Playit.gg plugin has been pre-installed.`
  });
  res.redirect('/admin/servers');
});

router.get('/servers/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const server = db.getServerById(req.params.id);
  if (!server) return res.redirect('/admin/servers');
  res.render('admin/server-form', { title: 'Edit Server', context: 'admin', server, users: db.getUsers(), error: null });
});

router.post('/servers/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { name, ownerId, type, version, port, ram, javaArgs } = req.body;
  db.updateServer(req.params.id, { name, ownerId, type, version, port: parseInt(port), ram: parseInt(ram), javaArgs });
  res.redirect('/admin/servers');
});

router.post('/servers/:id/delete', requireAdmin, (req, res) => {
  req.app.get('db').deleteServer(req.params.id);
  res.redirect('/admin/servers');
});

// Admin Notifications — send to users
router.get('/notifications', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const users = db.getUsers();
  // Get recent sent notifications (all notifs created by admin action)
  const allNotifs = users.flatMap(u => db.getNotifications(u.id))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 30);
  res.render('admin/notifications', {
    title: 'Send Notifications', context: 'admin',
    users, recentNotifs: allNotifs,
    success: req.query.success, error: req.query.error
  });
});

router.post('/notifications/send', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { target, userId, type, title, message } = req.body;

  if (!title || !title.trim() || !message || !message.trim()) {
    return res.redirect('/admin/notifications?error=missing_fields');
  }

  const users = db.getUsers();
  let recipients = [];

  if (target === 'all') {
    recipients = users;
  } else if (target === 'user' && userId) {
    const u = db.getUserById(userId);
    if (u) recipients = [u];
  } else if (target === 'role_admin') {
    recipients = users.filter(u => u.role === 'admin');
  } else if (target === 'role_user') {
    recipients = users.filter(u => u.role === 'user');
  }

  recipients.forEach(u => {
    db.createNotification(u.id, {
      type: type || 'info',
      title: title.trim(),
      message: message.trim()
    });
  });

  // Emit real-time notification count update via socket
  const io = req.app.get('io');
  if (io) {
    io.emit('notifications:new', { count: recipients.length });
  }

  res.redirect('/admin/notifications?success=' + recipients.length);
});

// Settings — with background upload
router.get('/settings', requireAdmin, (req, res) => {
  res.render('admin/settings', { title: 'Panel Settings', context: 'admin', success: req.query.success });
});

router.post('/settings', requireAdmin, upload.single('bgFile'), (req, res) => {
  const db = req.app.get('db');
  const {
    panelName, panelDescription, footerText, registrationEnabled,
    maxServersPerUser, defaultRam, defaultPort, siteIcon, headerIcon,
    smtpHost, smtpPort, smtpUser, smtpPass, smtpFrom,
    bgType, bgValue, cloudflareEnabled, cloudflareDomain, fixedServerIp
  } = req.body;

  const updates = {
    panelName, panelDescription, footerText,
    registrationEnabled: registrationEnabled === 'on',
    maxServersPerUser: parseInt(maxServersPerUser) || 5,
    defaultRam: parseInt(defaultRam) || 1024,
    defaultPort: parseInt(defaultPort) || 25565,
    siteIcon, headerIcon,
    smtpHost, smtpPort: parseInt(smtpPort) || 587,
    smtpUser, smtpPass, smtpFrom,
    bgType: bgType || 'none',
    bgValue: bgValue || '',
    bgOverlay: parseInt(req.body.bgOverlay) || 60,
    cloudflareEnabled: cloudflareEnabled === 'on',
    cloudflareDomain: cloudflareDomain || '',
    fixedServerIp: (fixedServerIp || '').trim()
  };

  // Handle uploaded background file (image/gif/video)
  if (req.file) {
    const b64 = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    updates.bgType = req.file.mimetype.startsWith('video') ? 'video' : 'image';
    updates.bgValue = b64;
  }

  db.saveSettings(updates);
  res.redirect('/admin/settings?success=1');
});

module.exports = router;
