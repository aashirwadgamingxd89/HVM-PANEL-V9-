const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Multer for avatar uploads — store as base64 in db (memory storage gives us buffer)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter(req, file, cb) {
    if (!file.mimetype.match(/^image\/(jpeg|png|gif|webp)$/)) {
      return cb(new Error('Only images allowed'));
    }
    cb(null, true);
  }
});

router.get('/', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  res.render('profile/index', {
    title: 'Profile', context: 'dashboard', user,
    success: req.query.success, error: null
  });
});

router.post('/update', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const { username, email } = req.body;
  const user = db.getUserById(req.session.userId);
  const existing = db.getUserByUsername(username);
  if (existing && existing.id !== user.id) {
    return res.render('profile/index', {
      title: 'Profile', context: 'dashboard', user,
      success: null, error: 'Username already taken.'
    });
  }
  db.updateUser(req.session.userId, { username, email });
  res.redirect('/profile?success=1');
});

router.post('/password', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const { currentPassword, newPassword, confirmPassword } = req.body;
  const user = db.getUserById(req.session.userId);
  if (!db.verifyPassword(user, currentPassword)) {
    return res.render('profile/index', {
      title: 'Profile', context: 'dashboard', user,
      success: null, error: 'Current password is incorrect.'
    });
  }
  if (newPassword !== confirmPassword) {
    return res.render('profile/index', {
      title: 'Profile', context: 'dashboard', user,
      success: null, error: 'New passwords do not match.'
    });
  }
  if (newPassword.length < 6) {
    return res.render('profile/index', {
      title: 'Profile', context: 'dashboard', user,
      success: null, error: 'Password must be at least 6 characters.'
    });
  }
  db.updateUser(req.session.userId, { password: newPassword });
  res.redirect('/profile?success=1');
});

// Avatar upload — converts to base64 data URL stored in user record
router.post('/avatar', requireAuth, (req, res, next) => {
  upload.single('avatar')(req, res, (err) => {
    if (err) {
      return res.redirect('/profile?error=upload_failed');
    }
    const db = req.app.get('db');
    if (!req.file || !req.file.buffer) return res.redirect('/profile?error=no_file');
    const b64 = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    db.updateUser(req.session.userId, { avatar: b64 });
    res.redirect('/profile?success=1');
  });
});

module.exports = router;
