const express = require('express');
const router = express.Router();
const { requireAuth, requireServerAccess } = require('../middleware/auth');
const path = require('path');
const fs = require('fs');

// Demo file tree for each folder path
function getDemoFiles(folderPath) {
  const trees = {
    '/': [
      { name: 'server.jar', type: 'file', size: '45.2 MB', modified: '2024-01-15', ext: 'jar' },
      { name: 'server.properties', type: 'file', size: '2.1 KB', modified: '2024-01-15', ext: 'properties' },
      { name: 'eula.txt', type: 'file', size: '130 B', modified: '2024-01-15', ext: 'txt' },
      { name: 'banned-players.json', type: 'file', size: '2 B', modified: '2024-01-15', ext: 'json' },
      { name: 'banned-ips.json', type: 'file', size: '2 B', modified: '2024-01-15', ext: 'json' },
      { name: 'ops.json', type: 'file', size: '2 B', modified: '2024-01-15', ext: 'json' },
      { name: 'whitelist.json', type: 'file', size: '2 B', modified: '2024-01-15', ext: 'json' },
      { name: 'world', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
      { name: 'plugins', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
      { name: 'logs', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
      { name: 'config', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
    ],
    '/plugins': [
      { name: 'EssentialsX-2.21.0.jar', type: 'file', size: '1.2 MB', modified: '2024-01-15', ext: 'jar' },
      { name: 'WorldEdit-7.3.2-dist.jar', type: 'file', size: '6.4 MB', modified: '2024-01-15', ext: 'jar' },
      { name: 'LuckPerms-Bukkit-5.4.137.jar', type: 'file', size: '2.1 MB', modified: '2024-01-15', ext: 'jar' },
      { name: 'playit-minecraft-plugin.jar', type: 'file', size: '890 KB', modified: '2024-01-15', ext: 'jar' },
      { name: 'Essentials', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
      { name: 'LuckPerms', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
    ],
    '/logs': [
      { name: 'latest.log', type: 'file', size: '24.5 KB', modified: '2024-01-15', ext: 'log' },
      { name: '2024-01-14-1.log.gz', type: 'file', size: '8.2 KB', modified: '2024-01-14', ext: 'gz' },
      { name: '2024-01-13-1.log.gz', type: 'file', size: '6.1 KB', modified: '2024-01-13', ext: 'gz' },
    ],
    '/world': [
      { name: 'level.dat', type: 'file', size: '14 KB', modified: '2024-01-15', ext: 'dat' },
      { name: 'session.lock', type: 'file', size: '8 B', modified: '2024-01-15', ext: 'lock' },
      { name: 'region', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
      { name: 'entities', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
      { name: 'playerdata', type: 'dir', size: '—', modified: '2024-01-15', ext: '' },
    ],
    '/config': [
      { name: 'paper-world-defaults.yml', type: 'file', size: '12 KB', modified: '2024-01-15', ext: 'yml' },
      { name: 'paper-global.yml', type: 'file', size: '8 KB', modified: '2024-01-15', ext: 'yml' },
      { name: 'bukkit.yml', type: 'file', size: '3 KB', modified: '2024-01-15', ext: 'yml' },
      { name: 'spigot.yml', type: 'file', size: '5 KB', modified: '2024-01-15', ext: 'yml' },
    ],
  };
  return trees[folderPath] || [
    { name: '(empty folder)', type: 'file', size: '—', modified: '—', ext: '' }
  ];
}

// Server overview
router.get('/:id/dashboard', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  const server = req.server;
  const owner = db.getUserById(server.ownerId);
  const backups = db.getBackups(server.id);
  const playitIp = db.getPlayitIp(server.id);
  res.render('servers/overview', {
    title: server.name, context: 'server', server, owner,
    backups: backups.slice(0, 3), isOwner: req.isOwner, playitIp
  });
});

// Console
router.get('/:id/console', requireAuth, requireServerAccess, (req, res) => {
  res.render('servers/console', { title: 'Console', context: 'server', server: req.server, isOwner: req.isOwner });
});

// File Manager — supports nested paths
router.get('/:id/files', requireAuth, requireServerAccess, (req, res) => {
  let currentPath = req.query.path || '/';
  // Normalize
  if (!currentPath.startsWith('/')) currentPath = '/' + currentPath;
  currentPath = currentPath.replace(/\/+/g, '/');

  const files = getDemoFiles(currentPath);
  const parts = currentPath.split('/').filter(Boolean);

  res.render('servers/files', {
    title: 'File Manager', context: 'server', server: req.server,
    files, currentPath, pathParts: parts, isOwner: req.isOwner
  });
});

// Players
router.get('/:id/players', requireAuth, requireServerAccess, (req, res) => {
  res.render('servers/players', {
    title: 'Players', context: 'server', server: req.server,
    players: [], whitelist: [], banned: [], ops: [], isOwner: req.isOwner
  });
});

// Worlds
router.get('/:id/worlds', requireAuth, requireServerAccess, (req, res) => {
  const worlds = [
    { name: 'world', type: 'normal', size: '24.5 MB', active: true },
    { name: 'world_nether', type: 'nether', size: '8.2 MB', active: false },
    { name: 'world_the_end', type: 'end', size: '3.1 MB', active: false },
  ];
  res.render('servers/worlds', { title: 'Worlds', context: 'server', server: req.server, worlds, isOwner: req.isOwner });
});

// Plugins
router.get('/:id/plugins', requireAuth, requireServerAccess, (req, res) => {
  const plugins = [
    { name: 'EssentialsX-2.21.0.jar', size: '1.2 MB' },
    { name: 'WorldEdit-7.3.2-dist.jar', size: '6.4 MB' },
    { name: 'LuckPerms-Bukkit-5.4.137.jar', size: '2.1 MB' },
    { name: 'playit-minecraft-plugin.jar', size: '890 KB' },
  ];
  const q = req.query.q || '';
  const filtered = q ? plugins.filter(p => p.name.toLowerCase().includes(q.toLowerCase())) : plugins;
  res.render('servers/plugins', {
    title: 'Plugins', context: 'server', server: req.server,
    plugins: filtered, q, isOwner: req.isOwner
  });
});

// Backups
router.get('/:id/backups', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  res.render('servers/backups', {
    title: 'Backups', context: 'server', server: req.server,
    backups: db.getBackups(req.server.id), isOwner: req.isOwner
  });
});

router.post('/:id/backups/create', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  db.createBackup({ serverId: req.server.id, name: req.body.name || `Backup-${new Date().toISOString().split('T')[0]}`, size: `${(Math.random()*100+10).toFixed(1)} MB` });
  res.redirect(`/servers/${req.server.id}/backups`);
});

router.post('/:id/backups/:bid/delete', requireAuth, requireServerAccess, (req, res) => {
  req.app.get('db').deleteBackup(req.params.bid);
  res.redirect(`/servers/${req.server.id}/backups`);
});

// Subusers
router.get('/:id/subusers', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  const subs = db.getSubusersByServer(req.server.id)
    .map(s => ({ ...s, user: db.getUserById(s.userId) })).filter(s => s.user);
  res.render('servers/subusers', { title: 'Subusers', context: 'server', server: req.server, subusers: subs, isOwner: req.isOwner });
});

router.post('/:id/subusers/add', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  const { username, permissions } = req.body;
  const targetUser = db.getUserByUsername(username);
  if (targetUser && targetUser.id !== req.session.userId) {
    const existing = db.getSubusersByServer(req.server.id).find(s => s.userId === targetUser.id);
    if (!existing) {
      db.addSubuser({ serverId: req.server.id, userId: targetUser.id, permissions: Array.isArray(permissions) ? permissions : [permissions].filter(Boolean) });
      db.createNotification(targetUser.id, { type: 'info', title: 'Server Access Granted', message: `You have been given access to "${req.server.name}".` });
    }
  }
  res.redirect(`/servers/${req.server.id}/subusers`);
});

router.post('/:id/subusers/:uid/remove', requireAuth, requireServerAccess, (req, res) => {
  req.app.get('db').removeSubuser(req.server.id, req.params.uid);
  res.redirect(`/servers/${req.server.id}/subusers`);
});

// Startup
router.get('/:id/startup', requireAuth, requireServerAccess, (req, res) => {
  res.render('servers/startup', { title: 'Startup', context: 'server', server: req.server, isOwner: req.isOwner });
});

router.post('/:id/startup', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  const { ram, javaArgs, type, version, autoRestart } = req.body;
  db.updateServer(req.server.id, { ram: parseInt(ram)||req.server.ram, javaArgs, type, version, autoRestart: autoRestart === 'on' });
  res.redirect(`/servers/${req.server.id}/startup`);
});

// Settings
router.get('/:id/settings', requireAuth, requireServerAccess, (req, res) => {
  res.render('servers/settings', { title: 'Settings', context: 'server', server: req.server, isOwner: req.isOwner, success: req.query.success });
});

router.post('/:id/settings', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  const { name, motd, port, gamemode, difficulty, maxPlayers } = req.body;
  db.updateServer(req.server.id, { name: name||req.server.name, motd: motd||req.server.motd, port: parseInt(port)||req.server.port, gamemode, difficulty, maxPlayers: parseInt(maxPlayers)||20 });
  res.redirect(`/servers/${req.server.id}/settings?success=1`);
});

router.post('/:id/settings/delete', requireAuth, requireServerAccess, (req, res) => {
  if (req.isOwner) req.app.get('db').deleteServer(req.server.id);
  res.redirect('/dashboard');
});

// Playit setup
router.post('/:id/playit/setup', requireAuth, requireServerAccess, (req, res) => {
  const db = req.app.get('db');
  const { playitIp } = req.body;
  if (playitIp && playitIp.trim()) {
    db.setPlayitIp(req.server.id, playitIp.trim());
    db.updateServer(req.server.id, { playitInstalled: true, playitIp: playitIp.trim() });
    db.createNotification(req.server.ownerId, { type: 'success', title: 'Playit.gg Connected', message: `Server IP set to ${playitIp.trim()} for ${req.server.name}` });
  }
  res.redirect(`/servers/${req.server.id}/dashboard`);
});

module.exports = router;
