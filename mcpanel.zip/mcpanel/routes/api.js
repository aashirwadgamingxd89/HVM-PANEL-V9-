const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');

router.post('/servers/:id/start', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false, error: 'Server not found' });

  db.updateServer(server.id, { status: 'online', startedAt: new Date().toISOString() });
  io.emit('server:statusChange', { serverId: server.id, status: 'online' });

  const ts = () => new Date().toLocaleTimeString('en-US', { hour12: false });

  // Simulate startup sequence with plugin loading
  const startupLogs = [
    `[${ts()}] [Server thread/INFO]: Starting ${server.name}...`,
    `[${ts()}] [Server thread/INFO]: Loading properties`,
    `[${ts()}] [Server thread/INFO]: Default game type: SURVIVAL`,
    `[${ts()}] [Server thread/INFO]: Preparing level "world"`,
  ];

  startupLogs.forEach((log, i) => {
    setTimeout(() => io.to(`console:${server.id}`).emit('console:line', log), i * 300);
  });

  // Plugin loading sequence
  const plugins = [
    'playit-minecraft-plugin.jar',
    'EssentialsX-2.21.0.jar',
    'WorldEdit-7.3.2-dist.jar',
    'LuckPerms-Bukkit-5.4.137.jar'
  ];
  plugins.forEach((plugin, i) => {
    setTimeout(() => {
      io.to(`console:${server.id}`).emit('console:line',
        `[${ts()}] [Server thread/INFO]: [PluginManager] Loading ${plugin}`);
    }, 1200 + i * 400);
  });
  plugins.forEach((plugin, i) => {
    const name = plugin.replace('.jar','').replace(/-[\d.]+(-dist)?$/,'');
    setTimeout(() => {
      io.to(`console:${server.id}`).emit('console:line',
        `[${ts()}] [Server thread/INFO]: [${name}] Enabling ${name}`);
    }, 2800 + i * 300);
  });

  // Playit startup message
  if (server.playitInstalled) {
    setTimeout(() => {
      const playitIp = server.playitIp || db.getPlayitIp(server.id);
      const addr = playitIp || 'not configured — run /playit in console';
      io.to(`console:${server.id}`).emit('console:line',
        `[${ts()}] [Server thread/INFO]: [playit-minecraft-plugin] Your server address: ${addr}`);
    }, 4000);
  }

  setTimeout(() => {
    io.to(`console:${server.id}`).emit('console:line',
      `[${ts()}] [Server thread/INFO]: Done (3.421s)! For help, type "help"`);
  }, 4500);

  res.json({ success: true, status: 'online' });
});

router.post('/servers/:id/stop', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false, error: 'Server not found' });

  db.updateServer(server.id, { status: 'offline', startedAt: null });
  io.emit('server:statusChange', { serverId: server.id, status: 'offline' });

  const ts = new Date().toLocaleTimeString('en-US', { hour12: false });
  io.to(`console:${server.id}`).emit('console:line', `[${ts}] [Server thread/INFO]: Stopping the server`);
  setTimeout(() => {
    io.to(`console:${server.id}`).emit('console:line', `[${ts}] [Server thread/INFO]: Saving chunks for level 'ServerLevel[world]'`);
  }, 500);
  setTimeout(() => {
    io.to(`console:${server.id}`).emit('console:line', `[${ts}] [Server thread/INFO]: ThreadedAnvilChunkStorage: All chunks are saved`);
  }, 1000);

  res.json({ success: true, status: 'offline' });
});

router.post('/servers/:id/restart', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false, error: 'Server not found' });

  db.updateServer(server.id, { status: 'offline' });
  io.emit('server:statusChange', { serverId: server.id, status: 'offline' });
  const ts = new Date().toLocaleTimeString('en-US', { hour12: false });
  io.to(`console:${server.id}`).emit('console:line', `[${ts}] [Server thread/INFO]: Restarting server...`);

  setTimeout(() => {
    db.updateServer(server.id, { status: 'online', startedAt: new Date().toISOString() });
    io.emit('server:statusChange', { serverId: server.id, status: 'online' });
    const ts2 = new Date().toLocaleTimeString('en-US', { hour12: false });
    io.to(`console:${server.id}`).emit('console:line', `[${ts2}] [Server thread/INFO]: Done (2.891s)! Server restarted.`);
  }, 3000);

  res.json({ success: true });
});

router.post('/servers/:id/command', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server || server.status !== 'online') return res.json({ success: false, error: 'Server not running' });
  io.emit('server:command', { serverId: server.id, command: req.body.command });
  res.json({ success: true });
});

router.get('/servers/:id/stats', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false });
  if (server.status === 'online') {
    res.json({ success: true, cpu: (Math.random()*30+5).toFixed(1), ram: Math.floor(Math.random()*512+200), disk: 1024, players: server.players||0, status: 'online' });
  } else {
    res.json({ success: true, cpu: 0, ram: 0, disk: 0, players: 0, status: 'offline' });
  }
});

// Playit IP save
router.post('/servers/:id/playit', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const { ip } = req.body;
  if (!ip) return res.json({ success: false });
  db.setPlayitIp(req.params.id, ip.trim());
  db.updateServer(req.params.id, { playitIp: ip.trim(), playitInstalled: true });
  res.json({ success: true, ip: ip.trim() });
});

// Versions
router.get('/versions/:type', (req, res) => {
  const versions = {
    paper: ['1.21.4','1.21.3','1.21.1','1.20.6','1.20.4','1.20.1','1.19.4','1.18.2'],
    purpur: ['1.21.4','1.21.3','1.21.1','1.20.6','1.20.4','1.20.1'],
    vanilla: ['1.21.4','1.21.3','1.21.1','1.20.6','1.20.4','1.20.1','1.19.4'],
    fabric: ['1.21.4','1.21.3','1.21.1','1.20.6','1.20.4'],
    forge: ['1.21.4','1.20.6','1.20.1','1.19.4','1.18.2'],
    mohist: ['1.20.1','1.19.2','1.18.2','1.16.5'],
    velocity: ['3.3.0','3.2.0','3.1.2'],
    waterfall: ['1.21','1.20','1.19','1.18']
  };
  res.json({ versions: versions[req.params.type] || [] });
});

// Marketplace search proxy
router.get('/plugins/search', async (req, res) => {
  const { q = '', source = 'modrinth' } = req.query;
  const all = [
    { name: 'EssentialsX', desc: 'The essential plugin suite for Bukkit servers.', downloads: '2.3M', version: '2.21.0', icon: '🔧', source: 'modrinth' },
    { name: 'WorldEdit', desc: 'An in-game open source map editor for Bukkit.', downloads: '1.8M', version: '7.3.2', icon: '🌍', source: 'modrinth' },
    { name: 'LuckPerms', desc: 'A permissions plugin for Minecraft servers.', downloads: '1.5M', version: '5.4.137', icon: '🔐', source: 'modrinth' },
    { name: 'WorldGuard', desc: 'Protect areas and control Minecraft gameplay.', downloads: '1.4M', version: '7.0.9', icon: '🛡️', source: 'modrinth' },
    { name: 'ViaVersion', desc: 'Allow newer versions to connect to old servers.', downloads: '2.1M', version: '4.9.4', icon: '🔌', source: 'hangar' },
    { name: 'PlaceholderAPI', desc: 'A plugin for other plugins to provide placeholders.', downloads: '1.6M', version: '2.11.6', icon: '📝', source: 'hangar' },
    { name: 'GriefPrevention', desc: 'Prevents all forms of grief using land claims.', downloads: '760K', version: '16.18.2', icon: '🏰', source: 'hangar' },
    { name: 'Vault', desc: 'Economy/Permission plugin bridge for Bukkit.', downloads: '1.2M', version: '1.7.3', icon: '🏦', source: 'spigot' },
    { name: 'Citizens', desc: 'The original NPC plugin for Bukkit servers.', downloads: '980K', version: '2.0.35', icon: '👤', source: 'spigot' },
    { name: 'ProtocolLib', desc: 'Provides read/write access to protocol packets.', downloads: '1.1M', version: '5.3.0', icon: '📡', source: 'spigot' },
    { name: 'Multiverse-Core', desc: 'Multi-world management plugin.', downloads: '890K', version: '4.3.13', icon: '🌐', source: 'spigot' },
    { name: 'ChestShop', desc: 'A simple and powerful shop plugin.', downloads: '640K', version: '3.12.2', icon: '🛒', source: 'spigot' },
    { name: 'dynmap', desc: 'A Google Maps-like map for your Minecraft server.', downloads: '1.1M', version: '3.7-beta', icon: '🗺️', source: 'curseforge' },
    { name: 'CoreProtect', desc: 'Fast, efficient block logging and rollback.', downloads: '950K', version: '22.4', icon: '📋', source: 'curseforge' },
    { name: 'Playit.gg', desc: 'Make your server public without port forwarding.', downloads: '320K', version: '1.0.5', icon: '🌐', source: 'modrinth' },
    { name: 'EconomyShopGUI', desc: 'A GUI shop with unlimited items and categories.', downloads: '410K', version: '6.0.2', icon: '🏪', source: 'spigot' },
    { name: 'TAB', desc: 'The most advanced TAB plugin for Minecraft.', downloads: '780K', version: '4.1.2', icon: '📊', source: 'hangar' },
    { name: 'Skript', desc: 'A plugin that allows you to customize with scripts.', downloads: '1.3M', version: '2.8.5', icon: '📜', source: 'hangar' },
    { name: 'MythicMobs', desc: 'Create custom mobs with unique AI and drops.', downloads: '550K', version: '5.6.1', icon: '👾', source: 'curseforge' },
    { name: 'HolographicDisplays', desc: 'Create holograms anywhere in your world.', downloads: '1.0M', version: '3.0.3', icon: '✨', source: 'spigot' },
  ];

  const qLower = q.toLowerCase().trim();
  const srcLower = source.toLowerCase();

  const filtered = all.filter(p => {
    const matchQ = !qLower || p.name.toLowerCase().includes(qLower) || p.desc.toLowerCase().includes(qLower);
    const matchSrc = srcLower === 'all' || p.source === srcLower;
    return matchQ && matchSrc;
  });

  // Sort: exact name matches first, then by downloads
  filtered.sort((a, b) => {
    const aExact = a.name.toLowerCase().startsWith(qLower) ? -1 : 0;
    const bExact = b.name.toLowerCase().startsWith(qLower) ? -1 : 0;
    return aExact - bExact;
  });

  res.json({ plugins: filtered, total: filtered.length });
});

module.exports = router;
