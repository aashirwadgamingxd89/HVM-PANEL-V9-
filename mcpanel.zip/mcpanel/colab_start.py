# Run this cell in Google Colab to start MCPanel

import subprocess
import threading
import time

# Install Node.js if not present
subprocess.run(['apt-get', 'install', '-y', 'nodejs', 'npm'], capture_output=True)

# Install dependencies
subprocess.run(['npm', 'install'], cwd='/content/mcpanel')

# Start the server in background
server = subprocess.Popen(['node', 'app.js'], cwd='/content/mcpanel',
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def print_output():
    for line in server.stdout:
        print(line.decode(), end='')

threading.Thread(target=print_output, daemon=True).start()
time.sleep(2)

# Start ngrok tunnel
from google.colab import output
output.serve_kernel_port_as_window(3000)
