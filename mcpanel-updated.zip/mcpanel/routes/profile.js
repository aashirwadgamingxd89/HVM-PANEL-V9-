const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Multer storage for avatars
const avatarStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '../public/avatars');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `avatar-${req.session.userId}${ext}`);
  }
});
const upload = multer({
  storage: avatarStorage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (['image/jpeg', 'image/png', 'image/gif', 'image/webp'].includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only image files are allowed'));
  }
});

router.get('/', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: req.query.success, error: null });
});

router.post('/update', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const { username, email } = req.body;
  const user = db.getUserById(req.session.userId);
  if (username !== user.username && db.getUserByUsername(username)) {
    const user2 = db.getUserById(req.session.userId);
    return res.render('profile/index', { title: 'Profile', context: 'dashboard', user: user2, success: null, error: 'Username already taken.' });
  }
  db.updateUser(req.session.userId, { username, email });
  res.redirect('/profile?success=1');
});

router.post('/password', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const { currentPassword, newPassword, confirmPassword } = req.body;
  const user = db.getUserById(req.session.userId);
  if (!db.verifyPassword(user, currentPassword)) {
    return res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: null, error: 'Current password is incorrect.' });
  }
  if (newPassword !== confirmPassword) {
    return res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: null, error: 'New passwords do not match.' });
  }
  db.updateUser(req.session.userId, { password: newPassword });
  res.redirect('/profile?success=1');
});

router.post('/avatar', requireAuth, (req, res) => {
  upload.single('avatar')(req, res, (err) => {
    const db = req.app.get('db');
    const user = db.getUserById(req.session.userId);
    if (err) {
      return res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: null, error: err.message });
    }
    if (!req.file) {
      return res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: null, error: 'No file uploaded.' });
    }
    const avatarUrl = `/avatars/${req.file.filename}`;
    db.updateUser(req.session.userId, { avatar: avatarUrl });
    res.redirect('/profile?success=1');
  });
});

module.exports = router;
