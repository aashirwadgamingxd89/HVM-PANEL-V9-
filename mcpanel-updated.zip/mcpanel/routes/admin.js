const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');

router.get('/', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const users = db.getUsers();
  const servers = db.getServers();
  res.render('admin/index', {
    title: 'Admin Overview',
    context: 'admin',
    users: users.slice(-5).reverse(),
    servers: servers.slice(-5).reverse(),
    stats: {
      totalUsers: users.length,
      totalServers: servers.length,
      runningServers: servers.filter(s => s.status === 'online').length,
      totalPlayers: servers.reduce((sum, s) => sum + (s.players || 0), 0)
    }
  });
});

// Users
router.get('/users', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const q = req.query.q || '';
  let users = db.getUsers();
  if (q) users = users.filter(u => u.username.includes(q) || u.email.includes(q));
  res.render('admin/users', { title: 'User Management', context: 'admin', users, q });
});

router.get('/users/create', requireAdmin, (req, res) => {
  res.render('admin/user-form', { title: 'Create User', context: 'admin', user: null, error: null });
});

router.post('/users/create', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { username, email, password, role, status, maxServers } = req.body;
  if (db.getUserByUsername(username)) {
    return res.render('admin/user-form', { title: 'Create User', context: 'admin', user: null, error: 'Username already taken.' });
  }
  db.createUser({ username, email, password, role, status, maxServers: parseInt(maxServers) || 5 });
  res.redirect('/admin/users');
});

router.get('/users/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const user = db.getUserById(req.params.id);
  if (!user) return res.redirect('/admin/users');
  res.render('admin/user-form', { title: 'Edit User', context: 'admin', user, error: null });
});

router.post('/users/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { username, email, password, role, status, maxServers } = req.body;
  const data = { username, email, role, status, maxServers: parseInt(maxServers) || 5 };
  if (password) data.password = password;
  db.updateUser(req.params.id, data);
  res.redirect('/admin/users');
});

router.post('/users/:id/delete', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  // Don't delete self
  if (req.params.id !== req.session.userId) {
    db.deleteUser(req.params.id);
  }
  res.redirect('/admin/users');
});

// Servers
router.get('/servers', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const q = req.query.q || '';
  let servers = db.getServers().map(s => ({ ...s, owner: db.getUserById(s.ownerId) }));
  if (q) servers = servers.filter(s => s.name.includes(q) || (s.owner && s.owner.username.includes(q)));
  res.render('admin/servers', { title: 'Server Management', context: 'admin', servers, q });
});

router.get('/servers/create', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const users = db.getUsers();
  res.render('admin/server-form', { title: 'Create Server', context: 'admin', server: null, users, error: null });
});

router.post('/servers/create', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { name, ownerId, type, version, port, ram, javaArgs } = req.body;
  const server = db.createServer({ name, ownerId, type, version, port: parseInt(port), ram: parseInt(ram), javaArgs });
  db.createNotification(ownerId, {
    type: 'success',
    title: 'Server Created',
    message: `Your server "${name}" has been created and is ready to use.`
  });
  res.redirect('/admin/servers');
});

router.get('/servers/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const server = db.getServerById(req.params.id);
  if (!server) return res.redirect('/admin/servers');
  const users = db.getUsers();
  res.render('admin/server-form', { title: 'Edit Server', context: 'admin', server, users, error: null });
});

router.post('/servers/:id/edit', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { name, ownerId, type, version, port, ram, javaArgs } = req.body;
  db.updateServer(req.params.id, { name, ownerId, type, version, port: parseInt(port), ram: parseInt(ram), javaArgs });
  res.redirect('/admin/servers');
});

router.post('/servers/:id/delete', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  db.deleteServer(req.params.id);
  res.redirect('/admin/servers');
});

// Settings
router.get('/settings', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  res.render('admin/settings', { title: 'Panel Settings', context: 'admin', success: req.query.success, db });
});

router.post('/settings', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { panelName, panelDescription, footerText, registrationEnabled, maxServersPerUser, defaultRam, defaultPort,
          siteIcon, headerIcon, smtpHost, smtpPort, smtpUser, smtpPass, smtpFrom } = req.body;
  db.saveSettings({
    panelName, panelDescription, footerText,
    registrationEnabled: registrationEnabled === 'on',
    maxServersPerUser: parseInt(maxServersPerUser) || 5,
    defaultRam: parseInt(defaultRam) || 1024,
    defaultPort: parseInt(defaultPort) || 25565,
    siteIcon, headerIcon,
    smtpHost, smtpPort: parseInt(smtpPort) || 587,
    smtpUser, smtpPass, smtpFrom
  });
  res.redirect('/admin/settings?success=1');
});

// Background upload
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const bgStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '../public/backgrounds');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `panel-bg${ext}`);
  }
});
const bgUpload = multer({ storage: bgStorage, limits: { fileSize: 20 * 1024 * 1024 } });

router.post('/settings/background', requireAdmin, bgUpload.single('backgroundFile'), (req, res) => {
  const db = req.app.get('db');
  const { panelBackgroundType, panelBackgroundUrl } = req.body;
  let bg = '';
  if (panelBackgroundType === 'url' && panelBackgroundUrl) {
    bg = panelBackgroundUrl;
  } else if (req.file) {
    bg = `/backgrounds/${req.file.filename}`;
  }
  db.saveSettings({ panelBackground: bg, panelBackgroundType });
  res.redirect('/admin/settings?success=1');
});

router.get('/settings/background/reset', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  db.saveSettings({ panelBackground: '', panelBackgroundType: 'none' });
  res.redirect('/admin/settings?success=1');
});

// Cloudflare settings
router.post('/settings/cloudflare', requireAdmin, (req, res) => {
  const db = req.app.get('db');
  const { cloudflareEnabled, cloudflareZoneId, cloudflareApiToken } = req.body;
  const update = {
    cloudflareEnabled: cloudflareEnabled === 'on',
    cloudflareZoneId: cloudflareZoneId || ''
  };
  if (cloudflareApiToken) update.cloudflareApiToken = cloudflareApiToken;
  db.saveSettings(update);
  res.redirect('/admin/settings?success=1');
});

// Firebase backup/restore
router.post('/settings/firebase/backup', requireAdmin, async (req, res) => {
  const db = req.app.get('db');
  const ok = await db.firebaseBackup();
  res.json({ success: ok, error: ok ? null : 'Firebase not configured. Install firebase-admin and add serviceAccountKey.json.' });
});

router.post('/settings/firebase/restore', requireAdmin, async (req, res) => {
  const db = req.app.get('db');
  const ok = await db.firebaseRestore();
  res.json({ success: ok, error: ok ? null : 'Firebase not configured or no backup found.' });
});

module.exports = router;
