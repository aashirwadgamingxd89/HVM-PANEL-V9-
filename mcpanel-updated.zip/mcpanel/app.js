const express = require('express');
const session = require('express-session');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db = require('./lib/db');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/avatars', express.static(path.join(__dirname, 'public/avatars')));

app.use(session({
  secret: 'mcpanel-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

// Attach db and io to app
app.set('db', db);
app.set('io', io);

// Global middleware: attach user to res.locals
app.use(async (req, res, next) => {
  res.locals.user = null;
  res.locals.settings = db.getSettings();
  res.locals.unreadCount = 0;
  if (req.session.userId) {
    const user = db.getUserById(req.session.userId);
    if (user) {
      res.locals.user = user;
      res.locals.unreadCount = db.getUnreadCount(user.id);
    }
  }
  next();
});

// Routes
app.use('/auth', require('./routes/auth'));
app.use('/dashboard', require('./routes/dashboard'));
app.use('/servers', require('./routes/servers'));
app.use('/admin', require('./routes/admin'));
app.use('/api', require('./routes/api'));
app.use('/profile', require('./routes/profile'));
app.use('/notifications', require('./routes/notifications'));

// Root redirect
app.get('/', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.redirect('/auth/login');
});

// Socket.IO
require('./lib/socket')(io, db);

// Init DB and start
db.init();
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`MCPanel running at http://localhost:${PORT}`);
});
