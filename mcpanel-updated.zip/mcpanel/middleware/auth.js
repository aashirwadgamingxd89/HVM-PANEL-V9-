function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.redirect('/auth/login');
  }
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  if (user && user.status === 'suspended') {
    req.session.destroy();
    return res.redirect('/auth/login?suspended=1');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.userId) return res.redirect('/auth/login');
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  if (!user || user.role !== 'admin') {
    return res.status(403).render('error', { title: 'Access Denied', message: 'You do not have permission to access this area.' });
  }
  if (user.status === 'suspended') {
    req.session.destroy();
    return res.redirect('/auth/login?suspended=1');
  }
  next();
}

function requireServerAccess(req, res, next) {
  if (!req.session.userId) return res.redirect('/auth/login');
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  if (!user) return res.redirect('/auth/login');
  if (user.status === 'suspended') {
    req.session.destroy();
    return res.redirect('/auth/login?suspended=1');
  }
  const server = db.getServerById(req.params.id);
  if (!server) return res.status(404).render('error', { title: 'Not Found', message: 'Server not found.' });

  if (user.role === 'admin' || server.ownerId === user.id) {
    req.server = server;
    req.isOwner = true;
    return next();
  }
  // Check subuser
  const subs = db.getSubusersByServer(server.id);
  const sub = subs.find(s => s.userId === user.id);
  if (sub) {
    req.server = server;
    req.isOwner = false;
    req.subuser = sub;
    return next();
  }
  res.status(403).render('error', { title: 'Access Denied', message: 'You do not have access to this server.' });
}

module.exports = { requireAuth, requireAdmin, requireServerAccess };
