const express = require('express');
const router = express.Router();

router.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.render('auth/login', { title: 'Login', error: null });
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const db = req.app.get('db');
  const user = db.getUserByUsername(username);
  if (!user || !db.verifyPassword(user, password)) {
    return res.render('auth/login', { title: 'Login', error: 'Invalid username or password.' });
  }
  if (user.status === 'suspended') {
    return res.render('auth/login', { title: 'Login', error: 'Your account has been suspended.' });
  }
  req.session.userId = user.id;
  res.redirect('/dashboard');
});

router.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  const settings = req.app.get('db').getSettings();
  if (!settings.registrationEnabled) return res.redirect('/auth/login');
  res.render('auth/register', { title: 'Register', error: null });
});

router.post('/register', async (req, res) => {
  const { username, email, password, confirmPassword } = req.body;
  const db = req.app.get('db');
  const settings = db.getSettings();
  if (!settings.registrationEnabled) return res.redirect('/auth/login');
  
  if (password !== confirmPassword) {
    return res.render('auth/register', { title: 'Register', error: 'Passwords do not match.' });
  }
  if (db.getUserByUsername(username)) {
    return res.render('auth/register', { title: 'Register', error: 'Username already taken.' });
  }
  if (db.getUserByEmail(email)) {
    return res.render('auth/register', { title: 'Register', error: 'Email already registered.' });
  }
  const user = db.createUser({ username, email, password });
  db.createNotification(user.id, {
    type: 'success',
    title: 'Welcome to MCPanel!',
    message: `Your account has been created. Start by creating your first Minecraft server.`
  });
  req.session.userId = user.id;
  res.redirect('/dashboard');
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/auth/login');
});

module.exports = router;
