const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');

router.get('/', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  const servers = db.getServersByUser(user.id);
  const allServers = db.getServers();
  const onlineCount = allServers.filter(s => s.status === 'online').length;
  const offlineCount = allServers.filter(s => s.status === 'offline').length;
  const totalPlayers = allServers.reduce((sum, s) => sum + (s.players || 0), 0);
  
  res.render('dashboard/index', {
    title: 'Dashboard',
    context: 'dashboard',
    servers,
    stats: {
      total: user.role === 'admin' ? allServers.length : servers.length,
      online: onlineCount,
      offline: offlineCount,
      players: totalPlayers
    }
  });
});

module.exports = router;
