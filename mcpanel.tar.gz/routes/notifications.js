const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');

router.get('/', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const notifications = db.getNotifications(req.session.userId);
  res.render('notifications/index', { title: 'Notifications', context: 'dashboard', notifications });
});

router.post('/read/:id', requireAuth, (req, res) => {
  const db = req.app.get('db');
  db.markNotificationRead(req.params.id);
  res.redirect('/notifications');
});

router.post('/read-all', requireAuth, (req, res) => {
  const db = req.app.get('db');
  db.markAllRead(req.session.userId);
  res.redirect('/notifications');
});

router.post('/delete/:id', requireAuth, (req, res) => {
  const db = req.app.get('db');
  db.deleteNotification(req.params.id);
  res.redirect('/notifications');
});

router.get('/settings', requireAuth, (req, res) => {
  res.render('notifications/settings', { title: 'Notification Settings', context: 'dashboard' });
});

module.exports = router;
