const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');

router.get('/', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const user = db.getUserById(req.session.userId);
  res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: req.query.success, error: null });
});

router.post('/update', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const { username, email } = req.body;
  const user = db.getUserById(req.session.userId);
  if (username !== user.username && db.getUserByUsername(username)) {
    const user2 = db.getUserById(req.session.userId);
    return res.render('profile/index', { title: 'Profile', context: 'dashboard', user: user2, success: null, error: 'Username already taken.' });
  }
  db.updateUser(req.session.userId, { username, email });
  res.redirect('/profile?success=1');
});

router.post('/password', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const { currentPassword, newPassword, confirmPassword } = req.body;
  const user = db.getUserById(req.session.userId);
  if (!db.verifyPassword(user, currentPassword)) {
    return res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: null, error: 'Current password is incorrect.' });
  }
  if (newPassword !== confirmPassword) {
    return res.render('profile/index', { title: 'Profile', context: 'dashboard', user, success: null, error: 'New passwords do not match.' });
  }
  db.updateUser(req.session.userId, { password: newPassword });
  res.redirect('/profile?success=1');
});

module.exports = router;
