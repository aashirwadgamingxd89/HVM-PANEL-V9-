const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');

router.post('/servers/:id/start', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false, error: 'Server not found' });
  
  db.updateServer(server.id, { status: 'online', startedAt: new Date().toISOString() });
  io.emit('server:statusChange', { serverId: server.id, status: 'online' });
  
  // Add a startup log
  const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
  io.to(`console:${server.id}`).emit('console:line', `[${timestamp}] [Server thread/INFO]: Starting ${server.name}...`);
  io.to(`console:${server.id}`).emit('console:line', `[${timestamp}] [Server thread/INFO]: Done! Server is now online.`);
  
  res.json({ success: true, status: 'online' });
});

router.post('/servers/:id/stop', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false, error: 'Server not found' });
  
  db.updateServer(server.id, { status: 'offline', startedAt: null });
  io.emit('server:statusChange', { serverId: server.id, status: 'offline' });
  
  const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
  io.to(`console:${server.id}`).emit('console:line', `[${timestamp}] [Server thread/INFO]: Stopping server...`);
  io.to(`console:${server.id}`).emit('console:line', `[${timestamp}] [Server thread/INFO]: Server stopped.`);
  
  res.json({ success: true, status: 'offline' });
});

router.post('/servers/:id/restart', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false, error: 'Server not found' });
  
  // First stop, then start
  db.updateServer(server.id, { status: 'offline' });
  io.emit('server:statusChange', { serverId: server.id, status: 'offline' });
  
  setTimeout(() => {
    db.updateServer(server.id, { status: 'online', startedAt: new Date().toISOString() });
    io.emit('server:statusChange', { serverId: server.id, status: 'online' });
    const ts = new Date().toLocaleTimeString('en-US', { hour12: false });
    io.to(`console:${server.id}`).emit('console:line', `[${ts}] [Server thread/INFO]: Server restarted successfully.`);
  }, 2000);
  
  const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
  io.to(`console:${server.id}`).emit('console:line', `[${timestamp}] [Server thread/INFO]: Restarting server...`);
  
  res.json({ success: true });
});

router.post('/servers/:id/command', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const io = req.app.get('io');
  const server = db.getServerById(req.params.id);
  if (!server || server.status !== 'online') return res.json({ success: false, error: 'Server not running' });
  
  const { command } = req.body;
  io.emit('server:command', { serverId: server.id, command });
  
  res.json({ success: true });
});

router.get('/servers/:id/stats', requireAuth, (req, res) => {
  const db = req.app.get('db');
  const server = db.getServerById(req.params.id);
  if (!server) return res.json({ success: false });
  
  if (server.status === 'online') {
    res.json({
      success: true,
      cpu: (Math.random() * 30 + 5).toFixed(1),
      ram: Math.floor(Math.random() * 512 + 200),
      disk: 1024,
      players: server.players || 0,
      status: 'online'
    });
  } else {
    res.json({ success: true, cpu: 0, ram: 0, disk: 0, players: 0, status: 'offline' });
  }
});

// Versions API
router.get('/versions/:type', async (req, res) => {
  const { type } = req.params;
  const versions = {
    paper: ['1.21.4', '1.21.3', '1.21.1', '1.20.6', '1.20.4', '1.20.1', '1.19.4', '1.18.2'],
    purpur: ['1.21.4', '1.21.3', '1.21.1', '1.20.6', '1.20.4', '1.20.1'],
    vanilla: ['1.21.4', '1.21.3', '1.21.1', '1.20.6', '1.20.4', '1.20.1', '1.19.4'],
    fabric: ['1.21.4', '1.21.3', '1.21.1', '1.20.6', '1.20.4'],
    forge: ['1.21.4', '1.20.6', '1.20.1', '1.19.4', '1.18.2'],
    mohist: ['1.20.1', '1.19.2', '1.18.2', '1.16.5'],
    velocity: ['3.3.0', '3.2.0', '3.1.2'],
    waterfall: ['1.21', '1.20', '1.19', '1.18']
  };
  res.json({ versions: versions[type] || [] });
});

module.exports = router;
