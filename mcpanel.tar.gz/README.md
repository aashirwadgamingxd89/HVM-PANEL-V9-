# MCPanel — Minecraft Server Management Panel

A full-featured Minecraft Server Management Panel built with Node.js + Express + EJS + Socket.IO.

## Features

- **Dashboard** — Server overview with live CPU/RAM/disk/player stats via Socket.IO
- **Console** — Real-time server log streaming and command execution
- **File Manager** — Browse, edit, upload, and delete server files
- **Players** — Manage online players, whitelist, banned players, and operators
- **Plugins** — Browse installed plugins and marketplace (Modrinth, Spigot, Hangar, CurseForge)
- **Worlds** — Manage world folders
- **Backups** — Create, download, and restore server backups
- **Startup** — Configure server type, version, RAM, and JVM arguments
- **Settings** — Server properties, MOTD, network settings
- **Subusers** — Grant other users access to your server with fine-grained permissions
- **Admin Panel** — Full user management, server management, and panel settings
- **Notifications** — Real-time notification system
- **Profile** — User profile and password management

## Tech Stack

- **Backend:** Node.js, Express.js, JSON file database, express-session, bcryptjs
- **Frontend:** EJS templates, Font Awesome 6.6, Inter font, vanilla JS
- **Real-time:** Socket.IO for live console and stats streaming
- **Auth:** Session-based with bcrypt password hashing

## Setup & Installation

```bash
# Install dependencies
npm install

# Start the panel
npm start
```

The panel starts at **http://localhost:3000**

## Default Credentials

- **Username:** `admin`
- **Password:** `admin123`

> ⚠️ Change the admin password immediately after first login!

## Server Software Support

- Paper, Purpur, Vanilla, Fabric, Forge, Mohist, Velocity, Waterfall

## Project Structure

```
mcpanel/
├── app.js              # Main entry point
├── lib/
│   ├── db.js           # JSON file database layer
│   └── socket.js       # Socket.IO real-time handler
├── middleware/
│   └── auth.js         # Authentication middleware
├── routes/
│   ├── auth.js         # Login/register/logout
│   ├── dashboard.js    # Main dashboard
│   ├── servers.js      # All server management routes
│   ├── admin.js        # Admin panel routes
│   ├── api.js          # REST API (start/stop/stats)
│   ├── profile.js      # User profile
│   └── notifications.js
├── views/
│   ├── partials/       # Shared sidebar, header
│   ├── auth/           # Login, register
│   ├── dashboard/      # Main dashboard
│   ├── servers/        # All server pages
│   ├── admin/          # Admin panel
│   ├── profile/        # User profile
│   └── notifications/
├── public/
│   └── css/style.css   # Full dark theme CSS
└── data/               # Auto-created on first run (JSON files)
```

## Configuration

All settings are managed through the Admin Panel at `/admin/settings`. No config files needed.

## Notes

- This is a **demo/prototype** panel — server processes are simulated. To connect to real Minecraft servers, integrate with `node-rcon`, `child_process` spawning, and `pidusage` for real metrics.
- Data is stored in `./data/*.json` files. For production, replace with SQLite or PostgreSQL.
