import { create } from 'zustand';

export const useChatStore = create((set, get) => ({
  conversations: [],
  activeConversationId: null,
  activeConversation: null,
  messages: {},
  typingUsers: {},
  unreadCounts: {},
  loadingMessages: false,

  setConversations: (conversations) => set({ conversations }),

  setActiveConversation: (id, data) =>
    set({ activeConversationId: id, activeConversation: data }),

  setMessages: (conversationId, messages) =>
    set((state) => ({
      messages: { ...state.messages, [conversationId]: messages },
    })),

  appendMessages: (conversationId, newMessages) =>
    set((state) => ({
      messages: {
        ...state.messages,
        [conversationId]: [
          ...newMessages,
          ...(state.messages[conversationId] || []),
        ],
      },
    })),

  addMessage: (conversationId, message) =>
    set((state) => {
      const existing = state.messages[conversationId] || [];
      const isDuplicate = existing.some((m) => m.id === message.id);
      if (isDuplicate) return state;
      return {
        messages: {
          ...state.messages,
          [conversationId]: [...existing, message],
        },
      };
    }),

  setTypingUser: (conversationId, uid, isTyping) =>
    set((state) => ({
      typingUsers: {
        ...state.typingUsers,
        [conversationId]: {
          ...(state.typingUsers[conversationId] || {}),
          [uid]: isTyping,
        },
      },
    })),

  setUnreadCount: (conversationId, count) =>
    set((state) => ({
      unreadCounts: { ...state.unreadCounts, [conversationId]: count },
    })),

  clearMessages: (conversationId) =>
    set((state) => {
      const msgs = { ...state.messages };
      delete msgs[conversationId];
      return { messages: msgs };
    }),

  setLoadingMessages: (loadingMessages) => set({ loadingMessages }),
}));
