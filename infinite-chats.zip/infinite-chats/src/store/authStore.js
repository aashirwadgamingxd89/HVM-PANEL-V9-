import { create } from 'zustand';

export const useAuthStore = create((set, get) => ({
  user: null,
  userProfile: null,
  loading: true,
  initialized: false,

  setUser: (user) => set({ user }),
  setUserProfile: (userProfile) => set({ userProfile }),
  setLoading: (loading) => set({ loading }),
  setInitialized: (initialized) => set({ initialized }),

  updateUserProfile: (updates) =>
    set((state) => ({
      userProfile: state.userProfile ? { ...state.userProfile, ...updates } : updates,
    })),

  clearAuth: () =>
    set({
      user: null,
      userProfile: null,
      loading: false,
    }),
}));
