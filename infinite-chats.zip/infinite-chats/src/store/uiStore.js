import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const ACCENT_COLORS = {
  indigo: { DEFAULT: '#6366f1', hover: '#4f46e5' },
  purple: { DEFAULT: '#8b5cf6', hover: '#7c3aed' },
  rose: { DEFAULT: '#f43f5e', hover: '#e11d48' },
  amber: { DEFAULT: '#f59e0b', hover: '#d97706' },
  emerald: { DEFAULT: '#10b981', hover: '#059669' },
  cyan: { DEFAULT: '#06b6d4', hover: '#0891b2' },
  orange: { DEFAULT: '#f97316', hover: '#ea580c' },
};

export const useUIStore = create(
  persist(
    (set, get) => ({
      // Theme
      colorMode: 'dark',
      accentColor: 'indigo',
      bubbleStyle: 'modern',
      fontSize: 'medium',
      messageDensity: 'comfortable',
      sidebarWidth: 'default',
      chatWallpaper: null,

      // UI state
      sidebarOpen: true,
      rightPanelOpen: false,
      activePanel: null, // 'search' | 'groups' | 'settings' | 'profile'
      gifPickerOpen: false,
      emojiPickerOpen: false,
      replyingTo: null,
      lightboxImage: null,

      // Sidebar
      searchQuery: '',
      activeTab: 'chats', // 'chats' | 'groups' | 'requests'

      setColorMode: (colorMode) => {
        set({ colorMode });
        const root = document.documentElement;
        if (colorMode === 'dark' || (colorMode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
          root.classList.add('dark');
        } else {
          root.classList.remove('dark');
        }
      },

      setAccentColor: (accentColor) => {
        set({ accentColor });
        const colors = ACCENT_COLORS[accentColor] || ACCENT_COLORS.indigo;
        document.documentElement.style.setProperty('--accent', colors.DEFAULT);
        document.documentElement.style.setProperty('--accent-hover', colors.hover);
      },

      applyTheme: () => {
        const { colorMode, accentColor } = get();
        const root = document.documentElement;
        if (colorMode === 'dark' || (colorMode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
          root.classList.add('dark');
        } else {
          root.classList.remove('dark');
        }
        const colors = ACCENT_COLORS[accentColor] || ACCENT_COLORS.indigo;
        root.style.setProperty('--accent', colors.DEFAULT);
        root.style.setProperty('--accent-hover', colors.hover);
      },

      setBubbleStyle: (bubbleStyle) => set({ bubbleStyle }),
      setFontSize: (fontSize) => set({ fontSize }),
      setMessageDensity: (messageDensity) => set({ messageDensity }),
      setSidebarWidth: (sidebarWidth) => set({ sidebarWidth }),
      setChatWallpaper: (chatWallpaper) => set({ chatWallpaper }),
      setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
      setRightPanelOpen: (rightPanelOpen) => set({ rightPanelOpen }),
      setActivePanel: (activePanel) => set({ activePanel }),
      setGifPickerOpen: (gifPickerOpen) => set({ gifPickerOpen }),
      setEmojiPickerOpen: (emojiPickerOpen) => set({ emojiPickerOpen }),
      setReplyingTo: (replyingTo) => set({ replyingTo }),
      setLightboxImage: (lightboxImage) => set({ lightboxImage }),
      setSearchQuery: (searchQuery) => set({ searchQuery }),
      setActiveTab: (activeTab) => set({ activeTab }),

      ACCENT_COLORS,
    }),
    {
      name: 'infinite-chats-ui',
      partialize: (state) => ({
        colorMode: state.colorMode,
        accentColor: state.accentColor,
        bubbleStyle: state.bubbleStyle,
        fontSize: state.fontSize,
        messageDensity: state.messageDensity,
        sidebarWidth: state.sidebarWidth,
      }),
    }
  )
);
