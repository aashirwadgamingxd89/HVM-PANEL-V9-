import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot, serverTimestamp, updateDoc } from 'firebase/firestore';
import { ref, onDisconnect, set as rtdbSet, onValue } from 'firebase/database';

import { auth, db, rtdb } from './lib/firebase';
import { useAuthStore } from './store/authStore';
import { useUIStore } from './store/uiStore';

import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ChatPage from './pages/ChatPage';
import ProfileSetupPage from './pages/ProfileSetupPage';
import ProtectedRoute from './components/auth/ProtectedRoute';
import LoadingScreen from './components/ui/LoadingScreen';

export default function App() {
  const { user, loading, setUser, setUserProfile, setLoading, setInitialized, clearAuth } = useAuthStore();
  const { applyTheme } = useUIStore();

  // Apply saved theme on mount
  useEffect(() => {
    applyTheme();
  }, [applyTheme]);

  // Listen to auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);

        // Listen to user profile in real time
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        const profileUnsub = onSnapshot(userDocRef, (snap) => {
          if (snap.exists()) {
            setUserProfile({ id: snap.id, ...snap.data() });
          }
          setLoading(false);
          setInitialized(true);
        }, (err) => {
          console.error('Profile listener error:', err);
          setLoading(false);
          setInitialized(true);
        });

        // Set up online/offline presence via RTDB
        const presenceRef = ref(rtdb, `presence/${firebaseUser.uid}`);
        const connectedRef = ref(rtdb, '.info/connected');

        const connUnsub = onValue(connectedRef, async (snap) => {
          if (snap.val() === true) {
            // When connected, set online and register disconnect hook
            onDisconnect(presenceRef).set({
              status: 'offline',
              lastSeen: Date.now(),
            });
            await rtdbSet(presenceRef, { status: 'online', lastSeen: Date.now() });

            // Also update Firestore
            try {
              await updateDoc(userDocRef, {
                status: 'online',
                lastSeen: serverTimestamp(),
              });
            } catch (e) { /* user doc might not exist yet */ }
          }
        });

        return () => {
          profileUnsub();
          connUnsub();
        };
      } else {
        clearAuth();
        setInitialized(true);
      }
    });

    return () => unsubscribe();
  }, []);

  if (loading) return <LoadingScreen />;

  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: 'var(--bg-surface)',
            color: 'var(--text-primary)',
            border: '1px solid var(--border)',
            borderRadius: '12px',
            fontFamily: 'Plus Jakarta Sans, sans-serif',
            fontSize: '14px',
          },
        }}
      />
      <Routes>
        <Route path="/login" element={!user ? <LoginPage /> : <Navigate to="/" replace />} />
        <Route path="/register" element={!user ? <RegisterPage /> : <Navigate to="/" replace />} />
        <Route path="/setup" element={
          <ProtectedRoute>
            <ProfileSetupPage />
          </ProtectedRoute>
        } />
        <Route path="/" element={
          <ProtectedRoute>
            <ChatPage />
          </ProtectedRoute>
        } />
        <Route path="/chat/:conversationId" element={
          <ProtectedRoute>
            <ChatPage />
          </ProtectedRoute>
        } />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
