import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { useAuthStore } from '../store/authStore';
import { updateUserProfile, uploadAvatar } from '../lib/userService';
import { doc, updateDoc, query, collection, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import Avatar from '../components/ui/Avatar';

export default function ProfileSetupPage() {
  const navigate = useNavigate();
  const { user, userProfile } = useAuthStore();
  const fileRef = useRef();

  const [form, setForm] = useState({
    displayName: userProfile?.displayName || user?.displayName || '',
    username: userProfile?.username || '',
    bio: userProfile?.bio || '',
  });
  const [avatar, setAvatar] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(userProfile?.photoURL || user?.photoURL || '');
  const [loading, setLoading] = useState(false);
  const [usernameError, setUsernameError] = useState('');

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return toast.error('Image must be under 5MB');
    setAvatar(file);
    setAvatarPreview(URL.createObjectURL(file));
  };

  const validateUsername = async (val) => {
    if (!val) return setUsernameError('Username is required');
    if (!/^[a-z0-9_]{3,20}$/.test(val)) return setUsernameError('3-20 chars: letters, numbers, underscore');
    if (val === userProfile?.username) return setUsernameError('');

    const q = query(collection(db, 'users'), where('username', '==', val));
    const snap = await getDocs(q);
    if (!snap.empty && snap.docs[0].id !== user.uid) {
      setUsernameError('Username already taken');
    } else {
      setUsernameError('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.displayName.trim()) return toast.error('Display name is required');
    if (!form.username.trim()) return toast.error('Username is required');
    if (usernameError) return toast.error(usernameError);

    setLoading(true);
    try {
      let photoURL = avatarPreview;

      if (avatar) {
        toast.loading('Uploading photo…', { id: 'upload' });
        photoURL = await uploadAvatar(user.uid, avatar, (p) => {
          toast.loading(`Uploading… ${Math.round(p)}%`, { id: 'upload' });
        });
        toast.dismiss('upload');
      }

      await updateUserProfile(user.uid, {
        displayName: form.displayName.trim(),
        username: form.username.trim().toLowerCase(),
        bio: form.bio.trim(),
        photoURL,
        profileComplete: true,
      });

      toast.success('Profile saved! 🎉');
      navigate('/');
    } catch (err) {
      console.error(err);
      toast.error('Failed to save profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'var(--bg-primary)' }}>
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-5 blur-3xl"
          style={{ background: 'var(--accent)' }} />
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center text-3xl"
            style={{ background: 'linear-gradient(135deg, var(--accent), #8b5cf6)', boxShadow: '0 8px 32px rgba(99,102,241,0.4)' }}>
            ∞
          </div>
          <h1 className="text-3xl font-extrabold text-white">Set up your profile</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>
            Tell others who you are
          </p>
        </div>

        <div className="rounded-2xl p-8 glass">
          {/* Avatar upload */}
          <div className="flex flex-col items-center mb-6">
            <div className="relative cursor-pointer" onClick={() => fileRef.current?.click()}>
              <div className="w-24 h-24 rounded-full overflow-hidden flex items-center justify-center text-4xl font-bold"
                style={{ background: avatarPreview ? 'transparent' : 'linear-gradient(135deg, var(--accent), #8b5cf6)' }}>
                {avatarPreview ? (
                  <img src={avatarPreview} alt="avatar" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-white">{form.displayName[0]?.toUpperCase() || '?'}</span>
                )}
              </div>
              <div className="absolute inset-0 rounded-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
                style={{ background: 'rgba(0,0,0,0.6)' }}>
                <span className="text-white text-xs font-semibold">Change</span>
              </div>
            </div>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
            <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
              Click to upload photo (max 5MB)
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Display Name *
              </label>
              <input
                type="text"
                value={form.displayName}
                onChange={update('displayName')}
                placeholder="How others see you"
                className="input-field"
                maxLength={50}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Username * <span style={{ color: 'var(--text-muted)' }}>(lowercase, 3-20 chars)</span>
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-medium"
                  style={{ color: 'var(--text-muted)' }}>@</span>
                <input
                  type="text"
                  value={form.username}
                  onChange={(e) => {
                    const val = e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
                    setForm((f) => ({ ...f, username: val }));
                    validateUsername(val);
                  }}
                  placeholder="your_username"
                  className="input-field pl-8"
                  maxLength={20}
                />
              </div>
              {usernameError && (
                <p className="text-xs mt-1 text-red-400">{usernameError}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Bio <span style={{ color: 'var(--text-muted)' }}>(optional, max 160)</span>
              </label>
              <textarea
                value={form.bio}
                onChange={update('bio')}
                placeholder="A few words about yourself…"
                className="input-field resize-none"
                rows={3}
                maxLength={160}
              />
              <p className="text-xs text-right mt-1" style={{ color: 'var(--text-muted)' }}>
                {form.bio.length}/160
              </p>
            </div>

            <button type="submit" disabled={loading || !!usernameError}
              className="btn-accent w-full py-3 text-sm disabled:opacity-50">
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Saving…
                </span>
              ) : 'Complete Setup →'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
