import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useChatStore } from '../store/chatStore';
import { useUIStore } from '../store/uiStore';
import { subscribeToConversations, subscribeToGroups } from '../lib/chatService';
import Sidebar from '../components/sidebar/Sidebar';
import ChatWindow from '../components/chat/ChatWindow';
import WelcomeScreen from '../components/chat/WelcomeScreen';
import SettingsPanel from '../components/settings/SettingsPanel';
import GroupCreateModal from '../components/groups/GroupCreateModal';
import ImageLightbox from '../components/ui/ImageLightbox';

export default function ChatPage() {
  const { conversationId } = useParams();
  const navigate = useNavigate();
  const { user, userProfile } = useAuthStore();
  const { setConversations, setActiveConversation, activeConversationId } = useChatStore();
  const { sidebarOpen, setSidebarOpen, lightboxImage, setLightboxImage } = useUIStore();
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [allConversations, setAllConversations] = useState([]);
  const [groups, setGroups] = useState([]);

  // Set active conversation from URL
  useEffect(() => {
    if (conversationId) {
      setActiveConversation(conversationId, null);
    } else {
      setActiveConversation(null, null);
    }
  }, [conversationId]);

  // Subscribe to conversations
  useEffect(() => {
    if (!user?.uid) return;
    const unsub = subscribeToConversations(user.uid, (convos) => {
      setAllConversations(convos);
      setConversations(convos);
    });
    return () => unsub();
  }, [user?.uid]);

  // Subscribe to groups
  useEffect(() => {
    if (!user?.uid) return;
    const unsub = subscribeToGroups(user.uid, (g) => setGroups(g));
    return () => unsub();
  }, [user?.uid]);

  const handleSelectConversation = (id) => {
    navigate(`/chat/${id}`);
    if (window.innerWidth < 768) setSidebarOpen(false);
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: 'var(--bg-primary)' }}>
      {/* Sidebar */}
      <div className={`
        ${sidebarOpen ? 'flex' : 'hidden md:flex'}
        flex-col flex-shrink-0 transition-all duration-300
        w-full md:w-80 lg:w-96
        absolute md:relative inset-0 md:inset-auto z-30 md:z-auto
      `}
        style={{ background: 'var(--bg-secondary)', borderRight: '1px solid var(--border)' }}>
        <Sidebar
          conversations={allConversations}
          groups={groups}
          onSelectConversation={handleSelectConversation}
          onNewGroup={() => setShowGroupModal(true)}
          onOpenSettings={() => setShowSettings(true)}
          activeId={conversationId}
        />
      </div>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {conversationId ? (
          <ChatWindow
            conversationId={conversationId}
            conversations={allConversations}
            groups={groups}
            onOpenSidebar={() => setSidebarOpen(true)}
          />
        ) : (
          <WelcomeScreen onNewGroup={() => setShowGroupModal(true)} />
        )}
      </div>

      {/* Settings panel */}
      {showSettings && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}>
          <SettingsPanel onClose={() => setShowSettings(false)} />
        </div>
      )}

      {/* Create group modal */}
      {showGroupModal && (
        <GroupCreateModal
          onClose={() => setShowGroupModal(false)}
          onCreated={(id) => {
            setShowGroupModal(false);
            navigate(`/chat/${id}`);
          }}
        />
      )}

      {/* Image lightbox */}
      {lightboxImage && (
        <ImageLightbox
          src={lightboxImage}
          onClose={() => setLightboxImage(null)}
        />
      )}
    </div>
  );
}
