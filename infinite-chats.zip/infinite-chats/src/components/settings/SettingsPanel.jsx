import React, { useState, useRef } from 'react';
import { toast } from 'react-hot-toast';
import { useAuthStore } from '../../store/authStore';
import { useUIStore } from '../../store/uiStore';
import { updateUserProfile, uploadAvatar } from '../../lib/userService';
import Avatar from '../ui/Avatar';

const SECTIONS = ['Account', 'Appearance', 'Privacy', 'Notifications', 'About'];

const ACCENT_OPTIONS = [
  { key: 'indigo', label: 'Indigo', color: '#6366f1' },
  { key: 'purple', label: 'Purple', color: '#8b5cf6' },
  { key: 'rose', label: 'Rose', color: '#f43f5e' },
  { key: 'amber', label: 'Amber', color: '#f59e0b' },
  { key: 'emerald', label: 'Emerald', color: '#10b981' },
  { key: 'cyan', label: 'Cyan', color: '#06b6d4' },
  { key: 'orange', label: 'Orange', color: '#f97316' },
];

const BUBBLE_STYLES = [
  { key: 'modern', label: 'Modern', desc: 'Rounded bubbles' },
  { key: 'sharp', label: 'Sharp', desc: 'Angular, Telegram-style' },
  { key: 'pill', label: 'Pill', desc: 'Full rounded ends' },
  { key: 'flat', label: 'Flat', desc: 'No shadow, minimal' },
];

export default function SettingsPanel({ onClose }) {
  const { user, userProfile } = useAuthStore();
  const {
    colorMode, setColorMode,
    accentColor, setAccentColor,
    bubbleStyle, setBubbleStyle,
    fontSize, setFontSize,
    messageDensity, setMessageDensity,
    sidebarWidth, setSidebarWidth,
  } = useUIStore();

  const [activeSection, setActiveSection] = useState('Account');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    displayName: userProfile?.displayName || '',
    bio: userProfile?.bio || '',
    username: userProfile?.username || '',
  });
  const [avatar, setAvatar] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(userProfile?.photoURL || '');
  const fileRef = useRef();

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSaveAccount = async () => {
    setSaving(true);
    try {
      let photoURL = avatarPreview;
      if (avatar) {
        photoURL = await uploadAvatar(user.uid, avatar);
      }
      await updateUserProfile(user.uid, { ...form, photoURL });
      toast.success('Profile updated!');
    } catch (e) {
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setAvatar(file);
    setAvatarPreview(URL.createObjectURL(file));
  };

  const handleColorModeChange = (mode) => {
    setColorMode(mode);
  };

  const handleAccentChange = (key) => {
    setAccentColor(key);
  };

  return (
    <div className="w-full max-w-2xl h-[85vh] rounded-2xl overflow-hidden flex shadow-2xl"
      style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border)' }}>
      {/* Sidebar nav */}
      <div className="w-48 flex-shrink-0 flex flex-col py-4"
        style={{ borderRight: '1px solid var(--border)', background: 'var(--bg-tertiary)' }}>
        <div className="px-4 mb-4">
          <h2 className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>Settings</h2>
        </div>
        <nav className="flex-1 px-2 space-y-0.5">
          {SECTIONS.map((s) => (
            <button
              key={s}
              onClick={() => setActiveSection(s)}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: activeSection === s ? 'rgba(99,102,241,0.15)' : 'transparent',
                color: activeSection === s ? 'var(--accent)' : 'var(--text-secondary)',
              }}
            >
              {s}
            </button>
          ))}
        </nav>
        <div className="px-4 pb-2">
          <button
            onClick={onClose}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-all hover:opacity-80"
            style={{ color: 'var(--text-muted)' }}
          >
            ← Close
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* ─── ACCOUNT ─── */}
        {activeSection === 'Account' && (
          <div className="space-y-5">
            <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Account</h3>

            {/* Avatar */}
            <div className="flex items-center gap-4">
              <div className="relative cursor-pointer" onClick={() => fileRef.current?.click()}>
                <div className="w-16 h-16 rounded-full overflow-hidden"
                  style={{ background: 'linear-gradient(135deg, var(--accent), #8b5cf6)' }}>
                  {avatarPreview ? (
                    <img src={avatarPreview} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-2xl font-bold text-white">
                      {form.displayName[0]?.toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="absolute inset-0 rounded-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
                  style={{ background: 'rgba(0,0,0,0.5)' }}>
                  <span className="text-white text-xs">Edit</span>
                </div>
              </div>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
              <div>
                <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                  {form.displayName}
                </p>
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>@{form.username}</p>
                <button onClick={() => fileRef.current?.click()}
                  className="text-xs mt-1 font-medium hover:underline" style={{ color: 'var(--accent)' }}>
                  Change photo
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Display Name
              </label>
              <input type="text" value={form.displayName} onChange={update('displayName')}
                className="input-field" maxLength={50} />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Username
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm"
                  style={{ color: 'var(--text-muted)' }}>@</span>
                <input type="text" value={form.username} onChange={update('username')}
                  className="input-field pl-8" maxLength={20} />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Bio
              </label>
              <textarea value={form.bio} onChange={update('bio')}
                className="input-field resize-none" rows={3} maxLength={160} />
              <p className="text-xs text-right mt-1" style={{ color: 'var(--text-muted)' }}>
                {form.bio.length}/160
              </p>
            </div>

            <button onClick={handleSaveAccount} disabled={saving} className="btn-accent px-6 py-2.5 text-sm disabled:opacity-50">
              {saving ? 'Saving…' : 'Save Changes'}
            </button>
          </div>
        )}

        {/* ─── APPEARANCE ─── */}
        {activeSection === 'Appearance' && (
          <div className="space-y-6">
            <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Appearance</h3>

            {/* Color Mode */}
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Color Mode</p>
              <div className="flex gap-2">
                {['light', 'dark', 'system'].map((mode) => (
                  <button
                    key={mode}
                    onClick={() => handleColorModeChange(mode)}
                    className="flex-1 py-2 rounded-xl text-sm font-semibold capitalize transition-all"
                    style={{
                      background: colorMode === mode ? 'var(--accent)' : 'var(--bg-tertiary)',
                      color: colorMode === mode ? 'white' : 'var(--text-secondary)',
                    }}
                  >
                    {mode === 'light' ? '☀️' : mode === 'dark' ? '🌙' : '⚙️'} {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Accent Color */}
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Accent Color</p>
              <div className="flex flex-wrap gap-2">
                {ACCENT_OPTIONS.map(({ key, label, color }) => (
                  <button
                    key={key}
                    onClick={() => handleAccentChange(key)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-medium transition-all"
                    style={{
                      background: accentColor === key ? color + '25' : 'var(--bg-tertiary)',
                      border: `2px solid ${accentColor === key ? color : 'transparent'}`,
                      color: accentColor === key ? color : 'var(--text-secondary)',
                    }}
                  >
                    <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: color }} />
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Bubble Style */}
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Bubble Style</p>
              <div className="grid grid-cols-2 gap-2">
                {BUBBLE_STYLES.map(({ key, label, desc }) => (
                  <button
                    key={key}
                    onClick={() => setBubbleStyle(key)}
                    className="p-3 rounded-xl text-left transition-all"
                    style={{
                      background: bubbleStyle === key ? 'rgba(99,102,241,0.1)' : 'var(--bg-tertiary)',
                      border: `1px solid ${bubbleStyle === key ? 'var(--accent)' : 'transparent'}`,
                    }}
                  >
                    <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{label}</p>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Font Size */}
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Font Size</p>
              <div className="flex gap-2">
                {['small', 'medium', 'large'].map((size) => (
                  <button
                    key={size}
                    onClick={() => {
                      setFontSize(size);
                      document.documentElement.setAttribute('data-fontsize', size);
                    }}
                    className="flex-1 py-2 rounded-xl text-sm font-semibold capitalize transition-all"
                    style={{
                      background: fontSize === size ? 'var(--accent)' : 'var(--bg-tertiary)',
                      color: fontSize === size ? 'white' : 'var(--text-secondary)',
                    }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Message Density */}
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Message Density</p>
              <div className="flex gap-2">
                {['compact', 'comfortable', 'spacious'].map((d) => (
                  <button
                    key={d}
                    onClick={() => setMessageDensity(d)}
                    className="flex-1 py-2 rounded-xl text-xs font-semibold capitalize transition-all"
                    style={{
                      background: messageDensity === d ? 'var(--accent)' : 'var(--bg-tertiary)',
                      color: messageDensity === d ? 'white' : 'var(--text-secondary)',
                    }}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Live preview */}
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Preview</p>
              <div className="rounded-xl p-4 space-y-2" style={{ background: 'var(--bg-primary)' }}>
                <div className="flex justify-start">
                  <div className="px-3 py-2 text-sm max-w-xs"
                    style={{
                      background: 'var(--bg-tertiary)',
                      color: 'var(--text-primary)',
                      borderRadius: bubbleStyle === 'sharp' ? '4px 12px 12px 12px' :
                        bubbleStyle === 'pill' ? '999px' :
                        bubbleStyle === 'flat' ? '8px' : '4px 18px 18px 18px',
                    }}>
                    Hey! How are you? 👋
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="px-3 py-2 text-sm text-white max-w-xs"
                    style={{
                      background: 'var(--accent)',
                      borderRadius: bubbleStyle === 'sharp' ? '12px 4px 12px 12px' :
                        bubbleStyle === 'pill' ? '999px' :
                        bubbleStyle === 'flat' ? '8px' : '18px 4px 18px 18px',
                    }}>
                    I'm great! Just testing themes 🎨
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ─── PRIVACY ─── */}
        {activeSection === 'Privacy' && (
          <div className="space-y-4">
            <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Privacy</h3>
            {[
              { label: 'Show Last Seen', desc: 'Let others see when you were last active' },
              { label: 'Read Receipts', desc: 'Show double ticks when messages are read' },
              { label: 'Allow Friend Requests', desc: 'Let others send you friend requests' },
            ].map((item) => (
              <ToggleItem key={item.label} label={item.label} desc={item.desc} />
            ))}
          </div>
        )}

        {/* ─── NOTIFICATIONS ─── */}
        {activeSection === 'Notifications' && (
          <div className="space-y-4">
            <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Notifications</h3>
            {[
              { label: 'Browser Notifications', desc: 'Show desktop notifications for new messages' },
              { label: 'Message Sounds', desc: 'Play sound when new message arrives' },
              { label: 'Friend Request Alerts', desc: 'Notify when someone sends a friend request' },
              { label: 'Group Mentions', desc: 'Notify when you are @mentioned in a group' },
            ].map((item) => (
              <ToggleItem key={item.label} label={item.label} desc={item.desc} defaultOn />
            ))}
          </div>
        )}

        {/* ─── ABOUT ─── */}
        {activeSection === 'About' && (
          <div className="space-y-4">
            <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>About</h3>
            <div className="flex flex-col items-center py-6">
              <div className="w-16 h-16 rounded-2xl mb-4 flex items-center justify-center text-3xl"
                style={{ background: 'linear-gradient(135deg, var(--accent), #8b5cf6)' }}>
                ∞
              </div>
              <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Infinite Chats</h2>
              <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>Connect beyond limits.</p>
              <p className="text-xs mt-3" style={{ color: 'var(--text-muted)' }}>Version 1.0.0</p>
            </div>
            <div className="space-y-1">
              {[
                { label: 'Firebase Project', value: 'telegram-app-cd720' },
                { label: 'Built with', value: 'React 18 + Vite + Firebase' },
                { label: 'Styling', value: 'TailwindCSS + CSS Variables' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between py-2 text-sm"
                  style={{ borderBottom: '1px solid var(--border)' }}>
                  <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
                  <span style={{ color: 'var(--text-muted)' }}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ToggleItem({ label, desc, defaultOn = false }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <div className="flex items-center justify-between py-3"
      style={{ borderBottom: '1px solid var(--border)' }}>
      <div>
        <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{label}</p>
        <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{desc}</p>
      </div>
      <button
        onClick={() => setOn(!on)}
        className="w-11 h-6 rounded-full transition-all duration-200 relative flex-shrink-0"
        style={{ background: on ? 'var(--accent)' : 'var(--bg-tertiary)' }}
      >
        <span
          className="absolute top-1 w-4 h-4 rounded-full bg-white transition-all duration-200"
          style={{ left: on ? '22px' : '4px' }}
        />
      </button>
    </div>
  );
}
