import React from 'react';
import { useAuthStore } from '../../store/authStore';

export default function WelcomeScreen({ onNewGroup }) {
  const { userProfile } = useAuthStore();

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center"
      style={{ background: 'var(--bg-primary)' }}>
      {/* Animated logo */}
      <div className="relative mb-8">
        <div
          className="w-24 h-24 rounded-3xl flex items-center justify-center text-5xl mb-6 mx-auto"
          style={{
            background: 'linear-gradient(135deg, var(--accent), #8b5cf6)',
            boxShadow: '0 20px 60px rgba(99,102,241,0.3)',
          }}
        >
          ∞
        </div>
        {/* Orbit dots */}
        <div className="absolute inset-0 animate-spin" style={{ animationDuration: '8s' }}>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full"
            style={{ background: 'var(--accent)', opacity: 0.6 }} />
        </div>
      </div>

      <h1 className="text-3xl font-extrabold mb-2 tracking-tight" style={{ color: 'var(--text-primary)' }}>
        Welcome back, {userProfile?.displayName?.split(' ')[0] || 'there'}! 👋
      </h1>
      <p className="text-base mb-8 max-w-md" style={{ color: 'var(--text-secondary)' }}>
        Connect beyond limits. Select a conversation from the sidebar or search for someone new to chat with.
      </p>

      {/* Action cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-lg w-full">
        {[
          {
            icon: '🔍',
            title: 'Find People',
            desc: 'Search by username',
            hint: 'Use the search bar in the sidebar',
          },
          {
            icon: '👥',
            title: 'Create Group',
            desc: 'Chat with many friends',
            action: onNewGroup,
          },
          {
            icon: '⚡',
            title: 'Real-time',
            desc: 'Instant messaging',
            hint: 'Messages deliver instantly',
          },
        ].map((card) => (
          <button
            key={card.title}
            onClick={card.action}
            className="flex flex-col items-center p-4 rounded-2xl text-center transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border)',
              cursor: card.action ? 'pointer' : 'default',
            }}
          >
            <span className="text-3xl mb-2">{card.icon}</span>
            <p className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>{card.title}</p>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{card.desc}</p>
          </button>
        ))}
      </div>

      <p className="text-xs mt-10" style={{ color: 'var(--text-muted)' }}>
        Infinite Chats — Connect beyond limits.
      </p>
    </div>
  );
}
