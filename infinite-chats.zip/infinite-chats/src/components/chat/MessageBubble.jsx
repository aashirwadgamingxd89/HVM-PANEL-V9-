import React, { useState, useRef } from 'react';
import { formatMessageTime, copyToClipboard, formatFileSize, getFileIcon } from '../../utils/helpers';
import { useUIStore } from '../../store/uiStore';
import Avatar from '../ui/Avatar';

const QUICK_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🔥'];

const getBubbleRadius = (bubbleStyle, isOwn) => {
  switch (bubbleStyle) {
    case 'sharp': return isOwn ? '12px 4px 12px 12px' : '4px 12px 12px 12px';
    case 'pill': return '999px';
    case 'flat': return '8px';
    default: return isOwn ? '18px 4px 18px 18px' : '4px 18px 18px 18px';
  }
};

export default function MessageBubble({
  message,
  isOwn,
  showAvatar,
  senderProfile,
  onReply,
  onReaction,
  onDelete,
  onImageClick,
  isGroup,
}) {
  const { bubbleStyle } = useUIStore();
  const [showActions, setShowActions] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const longPressTimer = useRef(null);

  if (message.deleted) {
    return (
      <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'} mb-1`}>
        <span className="text-xs italic px-3 py-1.5 rounded-xl"
          style={{ color: 'var(--text-muted)', background: 'var(--bg-tertiary)' }}>
          🚫 This message was deleted
        </span>
      </div>
    );
  }

  const radius = getBubbleRadius(bubbleStyle, isOwn);
  const reactions = message.reactions || {};
  const hasReactions = Object.values(reactions).some((uids) => uids?.length > 0);

  const handleLongPress = () => {
    longPressTimer.current = setTimeout(() => setShowActions(true), 500);
  };
  const cancelLongPress = () => clearTimeout(longPressTimer.current);

  const renderContent = () => {
    switch (message.type) {
      case 'gif':
        return (
          <div className="relative max-w-[240px]">
            <img
              src={message.gifUrl}
              alt={message.content || 'GIF'}
              className="rounded-xl w-full cursor-pointer hover:opacity-90 transition-opacity"
              loading="lazy"
              onClick={() => onImageClick?.(message.gifUrl)}
            />
            <span className="absolute top-1.5 left-1.5 text-xs font-bold px-1.5 py-0.5 rounded-md"
              style={{ background: 'rgba(0,0,0,0.6)', color: 'white' }}>
              GIF
            </span>
          </div>
        );

      case 'image':
        return (
          <div className="max-w-[260px]">
            <img
              src={message.fileData?.url}
              alt={message.content}
              className="rounded-xl w-full cursor-pointer hover:opacity-90 transition-opacity"
              loading="lazy"
              onClick={() => onImageClick?.(message.fileData?.url)}
            />
          </div>
        );

      case 'file':
        return (
          <a
            href={message.fileData?.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 min-w-[200px] max-w-[280px] px-3 py-2 rounded-xl no-underline transition-opacity hover:opacity-80"
            style={{ background: isOwn ? 'rgba(255,255,255,0.1)' : 'var(--bg-tertiary)' }}
          >
            <span className="text-2xl">{getFileIcon(message.fileData?.type)}</span>
            <div className="min-w-0">
              <p className="text-sm font-medium truncate" style={{ color: 'var(--text-primary)' }}>
                {message.content}
              </p>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {formatFileSize(message.fileData?.size)}
              </p>
            </div>
            <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2"
              viewBox="0 0 24 24" style={{ color: 'var(--text-muted)', flexShrink: 0 }}>
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
          </a>
        );

      default:
        return (
          <p className="text-sm leading-relaxed whitespace-pre-wrap break-words max-w-xs sm:max-w-sm"
            style={{ color: isOwn ? 'white' : 'var(--text-primary)' }}>
            {message.content}
          </p>
        );
    }
  };

  return (
    <div
      className={`flex gap-2 mb-1 group ${isOwn ? 'flex-row-reverse' : 'flex-row'} items-end`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => { setShowActions(false); setShowDeleteConfirm(false); }}
      onTouchStart={handleLongPress}
      onTouchEnd={cancelLongPress}
    >
      {/* Avatar (group chats) */}
      {!isOwn && isGroup && (
        <div className="flex-shrink-0 mb-1">
          {showAvatar ? <Avatar user={senderProfile} size="xs" /> : <div className="w-6" />}
        </div>
      )}

      <div className={`flex flex-col max-w-[75%] ${isOwn ? 'items-end' : 'items-start'}`}>
        {/* Sender name (group) */}
        {!isOwn && isGroup && showAvatar && (
          <span className="text-xs font-semibold mb-1 ml-1"
            style={{ color: 'var(--accent)' }}>
            {senderProfile?.displayName || 'Unknown'}
          </span>
        )}

        {/* Reply preview */}
        {message.replyTo && (
          <div className="mb-1 px-3 py-1.5 rounded-xl text-xs border-l-2 max-w-full"
            style={{
              background: 'var(--bg-tertiary)',
              borderLeftColor: 'var(--accent)',
              color: 'var(--text-muted)',
            }}>
            <p className="font-semibold mb-0.5" style={{ color: 'var(--text-secondary)' }}>
              Replying to message
            </p>
            <p className="truncate">{message.replyTo.content}</p>
          </div>
        )}

        <div className="relative">
          {/* Action buttons */}
          {showActions && (
            <div className={`absolute -top-8 flex items-center gap-1 z-10 ${isOwn ? 'right-0' : 'left-0'}`}>
              {/* Quick emoji reactions */}
              {QUICK_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => onReaction(emoji)}
                  className="w-7 h-7 rounded-full text-sm flex items-center justify-center transition-transform hover:scale-125 active:scale-95"
                  style={{ background: 'var(--bg-surface)' }}
                >
                  {emoji}
                </button>
              ))}

              {/* Reply */}
              <button
                onClick={onReply}
                className="w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110"
                style={{ background: 'var(--bg-surface)', color: 'var(--text-secondary)' }}
                title="Reply"
              >
                <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <polyline points="9 17 4 12 9 7"/>
                  <path d="M20 18v-2a4 4 0 0 0-4-4H4"/>
                </svg>
              </button>

              {/* Copy */}
              {message.type === 'text' && (
                <button
                  onClick={async () => {
                    await copyToClipboard(message.content);
                  }}
                  className="w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110"
                  style={{ background: 'var(--bg-surface)', color: 'var(--text-secondary)' }}
                  title="Copy"
                >
                  <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                  </svg>
                </button>
              )}

              {/* Delete */}
              {isOwn && (
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110"
                  style={{ background: 'var(--bg-surface)', color: '#ef4444' }}
                  title="Delete"
                >
                  <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
                  </svg>
                </button>
              )}
            </div>
          )}

          {/* Delete confirm */}
          {showDeleteConfirm && (
            <div className="absolute -top-20 z-20 rounded-xl py-2 px-3 shadow-xl flex flex-col gap-1"
              style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', right: isOwn ? 0 : 'auto', left: isOwn ? 'auto' : 0 }}>
              <p className="text-xs font-semibold" style={{ color: 'var(--text-primary)' }}>Delete message?</p>
              <div className="flex gap-1">
                <button onClick={() => { onDelete(false); setShowDeleteConfirm(false); }}
                  className="text-xs px-2 py-1 rounded-lg"
                  style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                  For me
                </button>
                <button onClick={() => { onDelete(true); setShowDeleteConfirm(false); }}
                  className="text-xs px-2 py-1 rounded-lg text-white"
                  style={{ background: '#ef4444' }}>
                  For all
                </button>
                <button onClick={() => setShowDeleteConfirm(false)}
                  className="text-xs px-2 py-1 rounded-lg"
                  style={{ color: 'var(--text-muted)' }}>
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Bubble */}
          <div
            className="px-3 py-2 animate-slide-up"
            style={{
              borderRadius: radius,
              background: isOwn ? 'var(--accent)' : 'var(--bg-tertiary)',
            }}
          >
            {renderContent()}

            {/* Timestamp + read receipt */}
            <div className={`flex items-center gap-1 mt-1 ${isOwn ? 'justify-end' : 'justify-start'}`}>
              <span className="text-xs" style={{ color: isOwn ? 'rgba(255,255,255,0.6)' : 'var(--text-muted)' }}>
                {formatMessageTime(message.timestamp)}
              </span>
              {isOwn && (
                <span className="text-xs" style={{ color: 'rgba(255,255,255,0.7)' }}>
                  {message.readBy?.length > 1 ? '✓✓' : '✓'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Reactions display */}
        {hasReactions && (
          <div className={`flex flex-wrap gap-1 mt-1 ${isOwn ? 'justify-end' : 'justify-start'}`}>
            {Object.entries(reactions).map(([emoji, uids]) =>
              uids?.length > 0 ? (
                <button
                  key={emoji}
                  onClick={() => onReaction(emoji)}
                  className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs transition-all hover:scale-110"
                  style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)' }}
                >
                  <span>{emoji}</span>
                  <span style={{ color: 'var(--text-secondary)' }}>{uids.length}</span>
                </button>
              ) : null
            )}
          </div>
        )}
      </div>
    </div>
  );
}
