import React, { useState, useEffect, useCallback } from 'react';
import { fetchTrendingGifs, searchGifs } from '../../lib/gifService';
import { debounce } from '../../utils/helpers';

export default function GifPicker({ onSelect, onClose }) {
  const [query, setQuery] = useState('');
  const [gifs, setGifs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [nextPos, setNextPos] = useState('');
  const [activeTab, setActiveTab] = useState('trending');

  useEffect(() => {
    loadTrending();
  }, []);

  const loadTrending = async () => {
    setLoading(true);
    try {
      const { gifs: data, next } = await fetchTrendingGifs(20);
      setGifs(data);
      setNextPos(next);
      setActiveTab('trending');
    } catch (e) {
      console.error('GIF load error:', e);
    } finally {
      setLoading(false);
    }
  };

  const doSearch = useCallback(
    debounce(async (q) => {
      if (!q.trim()) { loadTrending(); return; }
      setLoading(true);
      try {
        const { gifs: data, next } = await searchGifs(q, 20);
        setGifs(data);
        setNextPos(next);
        setActiveTab('search');
      } catch (e) {
        console.error('GIF search error:', e);
      } finally {
        setLoading(false);
      }
    }, 400),
    []
  );

  useEffect(() => {
    doSearch(query);
  }, [query]);

  // Split gifs into two columns for masonry
  const col1 = gifs.filter((_, i) => i % 2 === 0);
  const col2 = gifs.filter((_, i) => i % 2 !== 0);

  return (
    <div className="flex flex-col" style={{ height: '320px' }}>
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2 flex-shrink-0"
        style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="flex-1 relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5"
            style={{ color: 'var(--text-muted)' }}
            fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search GIFs…"
            className="w-full pl-8 pr-3 py-1.5 rounded-lg text-sm outline-none"
            style={{
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border)',
              color: 'var(--text-primary)',
            }}
            autoFocus
          />
        </div>
        <button onClick={onClose}
          className="w-7 h-7 rounded-lg flex items-center justify-center hover:opacity-80"
          style={{ color: 'var(--text-muted)', background: 'var(--bg-tertiary)' }}>
          <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M18 6 6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>

      {/* Tab indicator */}
      <div className="flex gap-2 px-3 py-1.5 flex-shrink-0">
        <span className="text-xs font-semibold capitalize" style={{ color: 'var(--text-muted)' }}>
          {activeTab === 'trending' ? '🔥 Trending' : `🔍 Results for "${query}"`}
        </span>
      </div>

      {/* GIF Grid */}
      <div className="flex-1 overflow-y-auto px-3 pb-3">
        {loading ? (
          <div className="gif-grid">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="gif-item skeleton rounded-xl" style={{ height: `${80 + (i % 3) * 30}px` }} />
            ))}
          </div>
        ) : gifs.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>No GIFs found</p>
          </div>
        ) : (
          <div className="flex gap-2">
            {[col1, col2].map((col, colIdx) => (
              <div key={colIdx} className="flex flex-col gap-2 flex-1">
                {col.map((gif) => (
                  <button
                    key={gif.id}
                    onClick={() => onSelect(gif)}
                    className="w-full rounded-xl overflow-hidden hover:opacity-90 transition-opacity active:scale-95 relative group"
                  >
                    <img
                      src={gif.previewUrl || gif.url}
                      alt={gif.title}
                      loading="lazy"
                      className="w-full h-auto block"
                      style={{ aspectRatio: `${gif.width}/${gif.height}` }}
                    />
                    <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity rounded-xl" />
                  </button>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Powered by Tenor */}
      <div className="flex-shrink-0 flex justify-center py-1.5">
        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Powered by Tenor</span>
      </div>
    </div>
  );
}
