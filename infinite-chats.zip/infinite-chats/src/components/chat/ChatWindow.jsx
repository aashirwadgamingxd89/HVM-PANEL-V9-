import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useChatStore } from '../../store/chatStore';
import { useUIStore } from '../../store/uiStore';
import {
  subscribeToMessages,
  sendMessage,
  setTypingStatus,
  markConversationRead,
  addReaction,
  deleteMessage,
} from '../../lib/chatService';
import { getUserProfile } from '../../lib/userService';
import { uploadChatFile } from '../../lib/userService';
import { debounce, formatMessageTime, formatLastSeen } from '../../utils/helpers';
import { toast } from 'react-hot-toast';
import Avatar from '../ui/Avatar';
import MessageBubble from './MessageBubble';
import MessageInput from './MessageInput';
import GifPicker from './GifPicker';

export default function ChatWindow({ conversationId, conversations, groups, onOpenSidebar }) {
  const { user, userProfile } = useAuthStore();
  const { messages, addMessage, setMessages, loadingMessages, setLoadingMessages, typingUsers } = useChatStore();
  const { replyingTo, setReplyingTo, setLightboxImage } = useUIStore();

  const [conversation, setConversation] = useState(null);
  const [otherUser, setOtherUser] = useState(null);
  const [isGroup, setIsGroup] = useState(false);
  const [groupData, setGroupData] = useState(null);
  const [gifPickerOpen, setGifPickerOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [memberProfiles, setMemberProfiles] = useState({});
  const [isAtBottom, setIsAtBottom] = useState(true);

  const messagesEndRef = useRef(null);
  const scrollRef = useRef(null);

  const convoMessages = messages[conversationId] || [];
  const typingUids = Object.entries(typingUsers[conversationId] || {})
    .filter(([uid, isTyping]) => isTyping && uid !== user.uid)
    .map(([uid]) => uid);

  // Resolve conversation info
  useEffect(() => {
    const convo = conversations.find((c) => c.id === conversationId);
    const group = groups.find((g) => g.id === conversationId);

    if (group) {
      setIsGroup(true);
      setGroupData(group);
      setConversation(group);
      // Load member profiles
      const loadMembers = async () => {
        const profiles = {};
        for (const m of group.members || []) {
          if (!memberProfiles[m.uid]) {
            const p = await getUserProfile(m.uid);
            if (p) profiles[m.uid] = p;
          }
        }
        setMemberProfiles((prev) => ({ ...prev, ...profiles }));
      };
      loadMembers();
    } else if (convo) {
      setIsGroup(false);
      setConversation(convo);
      const otherUid = convo.participants?.find((p) => p !== user.uid);
      if (otherUid) getUserProfile(otherUid).then(setOtherUser);
    }
  }, [conversationId, conversations, groups]);

  // Subscribe to messages
  useEffect(() => {
    if (!conversationId) return;
    setLoadingMessages(true);
    const unsub = subscribeToMessages(
      conversationId,
      (msgs) => {
        setMessages(conversationId, msgs);
        setLoadingMessages(false);
        markConversationRead(conversationId, user.uid);
      },
      isGroup
    );
    return () => unsub();
  }, [conversationId, isGroup]);

  // Auto scroll
  useEffect(() => {
    if (isAtBottom) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [convoMessages]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const threshold = 100;
    setIsAtBottom(el.scrollHeight - el.scrollTop - el.clientHeight < threshold);
  };

  // Typing indicator
  const stopTyping = useCallback(
    debounce(() => setTypingStatus(conversationId, user.uid, false, isGroup), 2000),
    [conversationId, isGroup]
  );

  const handleTyping = () => {
    setTypingStatus(conversationId, user.uid, true, isGroup);
    stopTyping();
  };

  const handleSendText = async (text) => {
    if (!text.trim()) return;
    try {
      await sendMessage({
        conversationId,
        senderId: user.uid,
        type: 'text',
        content: text,
        replyTo: replyingTo,
        isGroup,
      });
      setReplyingTo(null);
      setTypingStatus(conversationId, user.uid, false, isGroup);
    } catch (e) {
      toast.error('Failed to send message');
    }
  };

  const handleSendGif = async (gif) => {
    try {
      await sendMessage({
        conversationId,
        senderId: user.uid,
        type: 'gif',
        content: gif.title,
        gifUrl: gif.url,
        isGroup,
      });
      setGifPickerOpen(false);
    } catch (e) {
      toast.error('Failed to send GIF');
    }
  };

  const handleSendFile = async (file) => {
    if (file.size > 25 * 1024 * 1024) return toast.error('File must be under 25MB');
    setUploading(true);
    try {
      const isImage = file.type.startsWith('image/');
      const fileData = await uploadChatFile(conversationId, file, setUploadProgress);
      await sendMessage({
        conversationId,
        senderId: user.uid,
        type: isImage ? 'image' : 'file',
        content: file.name,
        fileData,
        isGroup,
      });
    } catch (e) {
      toast.error('Failed to upload file');
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleReaction = async (messageId, emoji) => {
    await addReaction(conversationId, messageId, emoji, user.uid, isGroup);
  };

  const handleDelete = async (messageId, forEveryone) => {
    await deleteMessage(conversationId, messageId, forEveryone, isGroup);
  };

  const displayName = isGroup
    ? groupData?.name
    : otherUser?.displayName || 'Loading…';

  const displayStatus = isGroup
    ? `${groupData?.members?.length || 0} members`
    : otherUser?.status === 'online'
    ? 'Online'
    : otherUser?.lastSeen
    ? `Last seen ${formatLastSeen(otherUser.lastSeen)}`
    : 'Offline';

  return (
    <div className="flex flex-col h-full" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3"
        style={{ borderBottom: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
        {/* Back button (mobile) */}
        <button
          onClick={onOpenSidebar}
          className="md:hidden w-8 h-8 flex items-center justify-center rounded-lg"
          style={{ color: 'var(--text-secondary)' }}
        >
          <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M15 18l-6-6 6-6"/>
          </svg>
        </button>

        {isGroup ? (
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-lg font-bold text-white"
            style={{ background: 'linear-gradient(135deg, var(--accent), #8b5cf6)' }}>
            {groupData?.photoURL ? (
              <img src={groupData.photoURL} alt={groupData.name} className="w-full h-full rounded-full object-cover" />
            ) : groupData?.name?.[0]}
          </div>
        ) : (
          <Avatar user={otherUser} size="sm" showStatus />
        )}

        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold truncate" style={{ color: 'var(--text-primary)' }}>
            {displayName}
          </p>
          <p className="text-xs" style={{
            color: otherUser?.status === 'online' ? '#34d399' : 'var(--text-muted)'
          }}>
            {typingUids.length > 0 ? (
              <span className="flex items-center gap-1.5">
                <span className="flex gap-0.5">
                  {[0,1,2].map(i => (
                    <span key={i} className="typing-dot" style={{ animationDelay: `${i * 0.2}s` }} />
                  ))}
                </span>
                typing…
              </span>
            ) : displayStatus}
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          <button className="w-8 h-8 rounded-lg flex items-center justify-center hover:opacity-80 transition-opacity"
            style={{ color: 'var(--text-secondary)', background: 'var(--bg-tertiary)' }}>
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
          </button>
          <button className="w-8 h-8 rounded-lg flex items-center justify-center hover:opacity-80 transition-opacity"
            style={{ color: 'var(--text-secondary)', background: 'var(--bg-tertiary)' }}>
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-4 py-4 space-y-1 chat-scroll"
        style={{ scrollbarWidth: 'thin' }}
      >
        {loadingMessages ? (
          <div className="space-y-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className={`flex ${i % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
                <div className="skeleton h-10 rounded-2xl" style={{ width: `${120 + Math.random() * 120}px` }} />
              </div>
            ))}
          </div>
        ) : (
          <>
            {convoMessages.map((msg, idx) => {
              const prevMsg = convoMessages[idx - 1];
              const showAvatar = isGroup &&
                msg.senderId !== user.uid &&
                (!prevMsg || prevMsg.senderId !== msg.senderId);
              const senderProfile = isGroup ? memberProfiles[msg.senderId] : otherUser;

              return (
                <MessageBubble
                  key={msg.id}
                  message={msg}
                  isOwn={msg.senderId === user.uid}
                  showAvatar={showAvatar}
                  senderProfile={senderProfile}
                  onReply={() => setReplyingTo(msg)}
                  onReaction={(emoji) => handleReaction(msg.id, emoji)}
                  onDelete={(forEveryone) => handleDelete(msg.id, forEveryone)}
                  onImageClick={(url) => setLightboxImage(url)}
                  isGroup={isGroup}
                />
              );
            })}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Scroll to bottom button */}
      {!isAtBottom && (
        <button
          onClick={() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })}
          className="absolute bottom-24 right-6 w-9 h-9 rounded-full flex items-center justify-center shadow-lg z-10"
          style={{ background: 'var(--accent)', color: 'white' }}
        >
          <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </button>
      )}

      {/* GIF Picker */}
      {gifPickerOpen && (
        <div className="flex-shrink-0 border-t"
          style={{ borderColor: 'var(--border)', background: 'var(--bg-secondary)' }}>
          <GifPicker onSelect={handleSendGif} onClose={() => setGifPickerOpen(false)} />
        </div>
      )}

      {/* Upload progress */}
      {uploading && (
        <div className="flex-shrink-0 px-4 py-2 flex items-center gap-3"
          style={{ background: 'var(--bg-secondary)', borderTop: '1px solid var(--border)' }}>
          <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
            style={{ color: 'var(--accent)' }} />
          <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--bg-tertiary)' }}>
            <div className="h-full rounded-full transition-all duration-200"
              style={{ width: `${uploadProgress}%`, background: 'var(--accent)' }} />
          </div>
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{Math.round(uploadProgress)}%</span>
        </div>
      )}

      {/* Message input */}
      <div className="flex-shrink-0"
        style={{ borderTop: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
        <MessageInput
          onSend={handleSendText}
          onTyping={handleTyping}
          onSendFile={handleSendFile}
          onGifOpen={() => setGifPickerOpen(!gifPickerOpen)}
          replyingTo={replyingTo}
          onCancelReply={() => setReplyingTo(null)}
        />
      </div>
    </div>
  );
}
