import React, { useState, useRef } from 'react';
import { toast } from 'react-hot-toast';
import { doc, updateDoc } from 'firebase/firestore';
import { useAuthStore } from '../../store/authStore';
import { db } from '../../lib/firebase';
import { createGroup } from '../../lib/chatService';
import { uploadGroupPhoto, getUserProfile } from '../../lib/userService';
import Avatar from '../ui/Avatar';

export default function GroupCreateModal({ onClose, onCreated }) {
  const { user, userProfile } = useAuthStore();
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState('');
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [memberSearch, setMemberSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const fileRef = useRef();

  const friends = userProfile?.friends || [];

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const toggleMember = (uid) => {
    setSelectedMembers((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const handleCreate = async () => {
    if (!name.trim()) return toast.error('Group name is required');
    setLoading(true);
    try {
      let photoURL = '';
      const groupId = await createGroup({
        name: name.trim(),
        photoURL,
        description: description.trim(),
        members: selectedMembers,
        createdBy: user.uid,
      });

      if (photo) {
        photoURL = await uploadGroupPhoto(groupId, photo);
        await updateDoc(doc(db, 'groups', groupId), { photoURL });
      }

      toast.success('Group created! 🎉');
      onCreated(groupId);
    } catch (e) {
      console.error(e);
      toast.error('Failed to create group');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
      style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border)' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4"
        style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="flex items-center gap-3">
          {step === 2 && (
            <button onClick={() => setStep(1)}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:opacity-80"
              style={{ color: 'var(--text-secondary)' }}>
              <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M15 18l-6-6 6-6"/>
              </svg>
            </button>
          )}
          <h2 className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>
            {step === 1 ? 'Create Group' : 'Add Members'}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1">
            {[1, 2, 3].map((s) => (
              <div key={s} className="w-5 h-1.5 rounded-full transition-all"
                style={{ background: step >= s ? 'var(--accent)' : 'var(--bg-tertiary)' }} />
            ))}
          </div>
          <button onClick={onClose}
            className="w-7 h-7 flex items-center justify-center rounded-lg hover:opacity-80"
            style={{ color: 'var(--text-muted)' }}>
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M18 6 6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </div>

      <div className="p-5">
        {/* Step 1: Group info */}
        {step === 1 && (
          <div className="space-y-4">
            {/* Photo upload */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => fileRef.current?.click()}
                className="w-20 h-20 rounded-full flex items-center justify-center text-3xl font-bold text-white transition-opacity hover:opacity-90 relative"
                style={{
                  background: photoPreview ? 'transparent' : 'linear-gradient(135deg, var(--accent), #8b5cf6)',
                }}
              >
                {photoPreview ? (
                  <img src={photoPreview} alt="group" className="w-full h-full rounded-full object-cover" />
                ) : (
                  <svg width="28" height="28" fill="none" stroke="white" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                    <circle cx="12" cy="13" r="4"/>
                  </svg>
                )}
              </button>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
              <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>Add group photo</p>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Group Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Design Team"
                className="input-field"
                maxLength={50}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Description <span style={{ color: 'var(--text-muted)' }}>(optional)</span>
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What's this group about?"
                className="input-field resize-none"
                rows={2}
                maxLength={200}
              />
            </div>

            <button
              onClick={() => { if (!name.trim()) return toast.error('Group name is required'); setStep(2); }}
              className="btn-accent w-full py-3 text-sm"
            >
              Next: Add Members →
            </button>
          </div>
        )}

        {/* Step 2: Add members */}
        {step === 2 && (
          <div className="space-y-3">
            <input
              type="text"
              value={memberSearch}
              onChange={(e) => setMemberSearch(e.target.value)}
              placeholder="Search friends…"
              className="input-field text-sm py-2"
            />

            {/* Selected count */}
            {selectedMembers.length > 0 && (
              <p className="text-xs font-semibold" style={{ color: 'var(--accent)' }}>
                {selectedMembers.length} member{selectedMembers.length > 1 ? 's' : ''} selected
              </p>
            )}

            {/* Friends list */}
            <div className="space-y-1 max-h-52 overflow-y-auto">
              {friends.length === 0 ? (
                <p className="text-sm text-center py-4" style={{ color: 'var(--text-muted)' }}>
                  No friends yet. Add friends first!
                </p>
              ) : (
                <FriendsList
                  friendUids={friends}
                  selectedMembers={selectedMembers}
                  onToggle={toggleMember}
                  search={memberSearch}
                />
              )}
            </div>

            <button
              onClick={() => setStep(3)}
              className="btn-accent w-full py-3 text-sm"
            >
              Preview Group →
            </button>
          </div>
        )}

        {/* Step 3: Preview + Create */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="flex flex-col items-center text-center py-2">
              <div className="w-16 h-16 rounded-full mb-3 flex items-center justify-center text-2xl font-bold text-white"
                style={{ background: photoPreview ? 'transparent' : 'linear-gradient(135deg, var(--accent), #8b5cf6)' }}>
                {photoPreview ? (
                  <img src={photoPreview} alt={name} className="w-full h-full rounded-full object-cover" />
                ) : name[0]?.toUpperCase()}
              </div>
              <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>{name}</h3>
              {description && (
                <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>{description}</p>
              )}
              <p className="text-xs mt-2" style={{ color: 'var(--text-secondary)' }}>
                {selectedMembers.length + 1} members (including you)
              </p>
            </div>

            <div className="flex gap-2">
              <button onClick={() => setStep(2)}
                className="flex-1 py-2.5 text-sm font-semibold rounded-xl transition-all hover:opacity-80"
                style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                Back
              </button>
              <button
                onClick={handleCreate}
                disabled={loading}
                className="flex-1 btn-accent py-2.5 text-sm disabled:opacity-50"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Creating…
                  </span>
                ) : '🚀 Create Group'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Subcomponent to load and list friends
function FriendsList({ friendUids, selectedMembers, onToggle, search }) {
  const [profiles, setProfiles] = React.useState({});

  React.useEffect(() => {
    friendUids.forEach(async (uid) => {
      if (!profiles[uid]) {
        const p = await getUserProfile(uid);
        if (p) setProfiles((prev) => ({ ...prev, [uid]: p }));
      }
    });
  }, [friendUids]);

  const filtered = friendUids.filter((uid) => {
    const p = profiles[uid];
    if (!p) return true;
    return (
      p.displayName?.toLowerCase().includes(search.toLowerCase()) ||
      p.username?.toLowerCase().includes(search.toLowerCase())
    );
  });

  return filtered.map((uid) => {
    const p = profiles[uid];
    const selected = selectedMembers.includes(uid);
    return (
      <button
        key={uid}
        onClick={() => onToggle(uid)}
        className="w-full flex items-center gap-3 px-3 py-2 rounded-xl transition-all text-left"
        style={{
          background: selected ? 'rgba(99,102,241,0.1)' : 'transparent',
          border: `1px solid ${selected ? 'var(--accent)' : 'transparent'}`,
        }}
      >
        <Avatar user={p} size="sm" showStatus />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
            {p?.displayName || uid}
          </p>
          <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>@{p?.username}</p>
        </div>
        <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0"
          style={{
            borderColor: selected ? 'var(--accent)' : 'var(--text-muted)',
            background: selected ? 'var(--accent)' : 'transparent',
          }}>
          {selected && (
            <svg width="10" height="10" fill="none" stroke="white" strokeWidth="3" viewBox="0 0 24 24">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          )}
        </div>
      </button>
    );
  });
}
