import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import LoadingScreen from '../ui/LoadingScreen';

export default function ProtectedRoute({ children }) {
  const { user, loading, userProfile, initialized } = useAuthStore();

  if (loading || !initialized) return <LoadingScreen />;
  if (!user) return <Navigate to="/login" replace />;

  // Redirect to setup if profile incomplete
  if (user && userProfile && !userProfile.profileComplete && window.location.pathname !== '/setup') {
    return <Navigate to="/setup" replace />;
  }

  return children;
}
