import React, { useState, useEffect, useCallback } from 'react';
import { toast } from 'react-hot-toast';
import { useAuthStore } from '../../store/authStore';
import { useChatStore } from '../../store/chatStore';
import { useUIStore } from '../../store/uiStore';
import { logout } from '../../lib/authService';
import { searchUsers, sendFriendRequest, acceptFriendRequest, declineFriendRequest, setUserStatus, getUserProfile } from '../../lib/userService';
import { debounce, formatConversationTime } from '../../utils/helpers';
import Avatar from '../ui/Avatar';
import ConversationItem from './ConversationItem';

const TABS = ['chats', 'groups', 'requests'];

export default function Sidebar({ conversations, groups, onSelectConversation, onNewGroup, onOpenSettings, activeId }) {
  const { user, userProfile } = useAuthStore();
  const { activeTab, setActiveTab, searchQuery, setSearchQuery } = useUIStore();
  const { unreadCounts } = useChatStore();

  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [friendProfiles, setFriendProfiles] = useState({});
  const [showStatusMenu, setShowStatusMenu] = useState(false);

  // Load friend profiles for requests
  useEffect(() => {
    const loadFriendProfiles = async () => {
      const requests = userProfile?.friendRequests || [];
      const profiles = {};
      for (const req of requests) {
        if (!friendProfiles[req.from]) {
          const p = await getUserProfile(req.from);
          if (p) profiles[req.from] = p;
        }
      }
      setFriendProfiles((prev) => ({ ...prev, ...profiles }));
    };
    loadFriendProfiles();
  }, [userProfile?.friendRequests]);

  const doSearch = useCallback(
    debounce(async (q) => {
      if (!q.trim()) return setSearchResults([]);
      setSearching(true);
      try {
        const results = await searchUsers(q, user.uid);
        const friends = userProfile?.friends || [];
        setSearchResults(results.filter((u) => !friends.includes(u.id)));
      } catch (e) {
        console.error(e);
      } finally {
        setSearching(false);
      }
    }, 300),
    [user?.uid, userProfile?.friends]
  );

  useEffect(() => {
    doSearch(searchQuery);
  }, [searchQuery]);

  const handleSendRequest = async (toUid) => {
    try {
      await sendFriendRequest(user.uid, toUid);
      toast.success('Friend request sent!');
    } catch (e) {
      toast.error('Failed to send request');
    }
  };

  const handleAccept = async (fromUid) => {
    try {
      const convoId = await acceptFriendRequest(user.uid, fromUid);
      toast.success('Friend added! 🎉');
      onSelectConversation(convoId);
    } catch (e) {
      toast.error('Failed to accept request');
    }
  };

  const handleDecline = async (fromUid) => {
    try {
      await declineFriendRequest(user.uid, fromUid);
      toast.success('Request declined');
    } catch (e) {
      toast.error('Failed to decline request');
    }
  };

  const handleStatusChange = async (status) => {
    try {
      await setUserStatus(user.uid, status);
      setShowStatusMenu(false);
    } catch (e) {
      toast.error('Failed to update status');
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch (e) {
      toast.error('Logout failed');
    }
  };

  const pendingRequests = userProfile?.friendRequests || [];
  const totalUnread = conversations.reduce((acc, c) => acc + (unreadCounts[c.id] || 0), 0);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex-shrink-0 p-4 flex items-center justify-between"
        style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="flex items-center gap-3">
          {/* Logo */}
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-lg font-bold text-white"
            style={{ background: 'linear-gradient(135deg, var(--accent), #8b5cf6)' }}>
            ∞
          </div>
          <span className="font-bold text-lg tracking-tight" style={{ color: 'var(--text-primary)' }}>
            Infinite Chats
          </span>
        </div>

        <div className="flex items-center gap-1">
          {/* New Group button */}
          <button
            onClick={onNewGroup}
            className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:opacity-80"
            style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}
            title="New Group"
          >
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
              <circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
          </button>

          {/* Settings */}
          <button
            onClick={onOpenSettings}
            className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:opacity-80"
            style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}
            title="Settings"
          >
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="flex-shrink-0 p-3">
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4"
            style={{ color: 'var(--text-muted)' }}
            fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search users or chats…"
            className="input-field pl-9 py-2 text-sm"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2"
              style={{ color: 'var(--text-muted)' }}>
              <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M18 6 6 18M6 6l12 12"/>
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex-shrink-0 px-3 pb-2 flex gap-1">
        {TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className="flex-1 py-1.5 text-xs font-semibold rounded-lg capitalize relative transition-all duration-200"
            style={{
              background: activeTab === tab ? 'var(--accent)' : 'var(--bg-tertiary)',
              color: activeTab === tab ? 'white' : 'var(--text-secondary)',
            }}
          >
            {tab}
            {tab === 'requests' && pendingRequests.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-white text-xs flex items-center justify-center"
                style={{ background: '#ef4444', fontSize: '10px' }}>
                {pendingRequests.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Search results */}
        {searchQuery && (
          <div className="px-3 pb-3">
            <p className="text-xs font-semibold mb-2 px-1" style={{ color: 'var(--text-muted)' }}>
              SEARCH RESULTS
            </p>
            {searching && (
              <div className="flex items-center gap-2 px-3 py-2">
                <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
                  style={{ color: 'var(--text-muted)' }} />
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Searching…</span>
              </div>
            )}
            {!searching && searchResults.length === 0 && (
              <p className="text-sm px-3 py-2" style={{ color: 'var(--text-muted)' }}>No users found</p>
            )}
            {searchResults.map((u) => (
              <div key={u.id} className="sidebar-item">
                <Avatar user={u} size="md" showStatus />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
                    {u.displayName}
                  </p>
                  <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>@{u.username}</p>
                </div>
                <button
                  onClick={() => handleSendRequest(u.id)}
                  className="btn-accent py-1 px-2 text-xs"
                >
                  Add
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Chats tab */}
        {!searchQuery && activeTab === 'chats' && (
          <>
            {conversations.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
                <div className="text-4xl mb-3">💬</div>
                <p className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>No conversations yet</p>
                <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                  Search for users above to add friends and start chatting
                </p>
              </div>
            ) : (
              conversations.map((convo) => (
                <ConversationItem
                  key={convo.id}
                  conversation={convo}
                  active={convo.id === activeId}
                  onClick={() => onSelectConversation(convo.id)}
                  unread={unreadCounts[convo.id] || 0}
                />
              ))
            )}
          </>
        )}

        {/* Groups tab */}
        {!searchQuery && activeTab === 'groups' && (
          <>
            <div className="px-3 pb-2">
              <button
                onClick={onNewGroup}
                className="w-full flex items-center gap-2 py-2 px-3 rounded-xl text-sm font-semibold transition-colors"
                style={{ background: 'rgba(99,102,241,0.1)', color: 'var(--accent)' }}
              >
                <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="10"/><path d="M12 8v8M8 12h8"/>
                </svg>
                Create New Group
              </button>
            </div>
            {groups.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
                <div className="text-4xl mb-3">👥</div>
                <p className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>No groups yet</p>
                <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Create a group to chat with multiple people</p>
              </div>
            ) : (
              groups.map((group) => (
                <div
                  key={group.id}
                  onClick={() => onSelectConversation(group.id)}
                  className={`sidebar-item mx-3 mb-1 ${group.id === activeId ? 'active' : ''}`}
                >
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold text-white flex-shrink-0"
                    style={{ background: 'linear-gradient(135deg, var(--accent), #8b5cf6)' }}>
                    {group.photoURL ? (
                      <img src={group.photoURL} alt={group.name} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      group.name[0]?.toUpperCase()
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{group.name}</p>
                    <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>
                      {group.members?.length || 0} members
                    </p>
                  </div>
                </div>
              ))
            )}
          </>
        )}

        {/* Requests tab */}
        {!searchQuery && activeTab === 'requests' && (
          <>
            {pendingRequests.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
                <div className="text-4xl mb-3">🤝</div>
                <p className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>No pending requests</p>
              </div>
            ) : (
              pendingRequests.map((req) => {
                const profile = friendProfiles[req.from];
                return (
                  <div key={req.from} className="sidebar-item mx-3 mb-1">
                    <Avatar user={profile} size="md" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
                        {profile?.displayName || 'Unknown'}
                      </p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>@{profile?.username}</p>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => handleAccept(req.from)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs"
                        style={{ background: '#10b981' }}>
                        ✓
                      </button>
                      <button onClick={() => handleDecline(req.from)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-xs"
                        style={{ background: 'var(--bg-tertiary)', color: 'var(--text-muted)' }}>
                        ✕
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </>
        )}
      </div>

      {/* User profile footer */}
      <div className="flex-shrink-0 p-3 flex items-center gap-3"
        style={{ borderTop: '1px solid var(--border)' }}>
        <div className="relative">
          <Avatar user={userProfile} size="md" showStatus />
          {/* Status menu trigger */}
          <button
            onClick={() => setShowStatusMenu(!showStatusMenu)}
            className="absolute inset-0 rounded-full"
          />
          {showStatusMenu && (
            <div className="absolute bottom-12 left-0 w-40 rounded-xl py-1 z-50 shadow-xl"
              style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)' }}>
              {[
                { status: 'online', label: 'Online', color: '#34d399' },
                { status: 'dnd', label: 'Do Not Disturb', color: '#ef4444' },
                { status: 'offline', label: 'Appear Offline', color: '#6b7280' },
              ].map(({ status, label, color }) => (
                <button key={status} onClick={() => handleStatusChange(status)}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:opacity-80 transition-opacity"
                  style={{ color: 'var(--text-primary)' }}>
                  <span className="w-2 h-2 rounded-full" style={{ background: color }} />
                  {label}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
            {userProfile?.displayName}
          </p>
          <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>
            @{userProfile?.username}
          </p>
        </div>

        <button onClick={handleLogout}
          className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:opacity-80"
          style={{ background: 'var(--bg-tertiary)', color: 'var(--text-muted)' }}
          title="Logout">
          <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
            <polyline points="16 17 21 12 16 7"/>
            <line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
