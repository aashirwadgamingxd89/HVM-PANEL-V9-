import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/authStore';
import { getUserProfile } from '../../lib/userService';
import { formatConversationTime } from '../../utils/helpers';
import Avatar from '../ui/Avatar';

export default function ConversationItem({ conversation, active, onClick, unread }) {
  const { user } = useAuthStore();
  const [otherUser, setOtherUser] = useState(null);

  const isDM = conversation.type === 'dm';
  const otherUid = isDM ? conversation.participants?.find((p) => p !== user.uid) : null;

  useEffect(() => {
    if (otherUid) {
      getUserProfile(otherUid).then(setOtherUser);
    }
  }, [otherUid]);

  const lastMsg = conversation.lastMessage;
  const time = lastMsg?.timestamp ? formatConversationTime(lastMsg.timestamp) : '';

  const getPreview = () => {
    if (!lastMsg) return 'No messages yet';
    if (lastMsg.type === 'gif') return '🎞️ GIF';
    if (lastMsg.type === 'image') return '📷 Image';
    if (lastMsg.type === 'file') return '📎 File';
    return lastMsg.text || '…';
  };

  const displayName = isDM
    ? (otherUser?.displayName || 'Loading…')
    : conversation.name || 'Group';

  const displayUser = isDM ? otherUser : {
    displayName: conversation.name,
    photoURL: conversation.photoURL,
  };

  return (
    <div
      onClick={onClick}
      className={`sidebar-item mx-3 mb-0.5 cursor-pointer ${active ? 'active' : ''}`}
    >
      <Avatar user={displayUser} size="md" showStatus={isDM} />

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
            {displayName}
          </p>
          {time && (
            <span className="text-xs flex-shrink-0" style={{ color: 'var(--text-muted)' }}>
              {time}
            </span>
          )}
        </div>
        <div className="flex items-center justify-between gap-2 mt-0.5">
          <p className="text-xs truncate" style={{ color: unread > 0 ? 'var(--text-secondary)' : 'var(--text-muted)' }}>
            {getPreview()}
          </p>
          {unread > 0 && (
            <span className="flex-shrink-0 min-w-[18px] h-[18px] rounded-full text-white text-xs flex items-center justify-center px-1"
              style={{ background: 'var(--accent)', fontSize: '10px' }}>
              {unread > 99 ? '99+' : unread}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
