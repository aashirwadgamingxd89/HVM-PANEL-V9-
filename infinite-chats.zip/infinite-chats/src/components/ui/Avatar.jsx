import React from 'react';
import { generateAvatarColor, getInitials } from '../../utils/helpers';

const sizeMap = {
  xs: 'w-6 h-6 text-xs',
  sm: 'w-8 h-8 text-sm',
  md: 'w-10 h-10 text-base',
  lg: 'w-12 h-12 text-lg',
  xl: 'w-16 h-16 text-2xl',
  '2xl': 'w-20 h-20 text-3xl',
};

const dotSizeMap = {
  xs: 'w-1.5 h-1.5',
  sm: 'w-2 h-2',
  md: 'w-2.5 h-2.5',
  lg: 'w-3 h-3',
  xl: 'w-3.5 h-3.5',
  '2xl': 'w-4 h-4',
};

export default function Avatar({ user, size = 'md', showStatus = false, className = '' }) {
  const name = user?.displayName || user?.username || '?';
  const photoURL = user?.photoURL;
  const status = user?.status || 'offline';

  const avatarColor = generateAvatarColor(name);
  const initials = getInitials(name);

  return (
    <div className={`relative flex-shrink-0 ${className}`}>
      <div
        className={`${sizeMap[size]} rounded-full overflow-hidden flex items-center justify-center font-semibold text-white select-none`}
        style={!photoURL ? { background: avatarColor } : {}}
      >
        {photoURL ? (
          <img
            src={photoURL}
            alt={name}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.parentNode.style.background = avatarColor;
              e.target.parentNode.textContent = initials;
            }}
          />
        ) : (
          <span>{initials}</span>
        )}
      </div>

      {showStatus && (
        <span
          className={`absolute bottom-0 right-0 ${dotSizeMap[size]} rounded-full border-2 border-[var(--bg-secondary)]`}
          style={{
            background:
              status === 'online'
                ? '#34d399'
                : status === 'dnd'
                ? '#ef4444'
                : '#6b7280',
          }}
        />
      )}
    </div>
  );
}
