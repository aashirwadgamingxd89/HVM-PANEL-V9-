import React from 'react';

export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center z-50"
      style={{ background: 'var(--bg-primary)' }}>
      {/* Animated logo */}
      <div className="relative mb-6">
        <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl"
          style={{
            background: 'linear-gradient(135deg, var(--accent), #8b5cf6)',
            boxShadow: '0 0 40px rgba(99,102,241,0.4)',
          }}>
          ∞
        </div>
        {/* Glow ring */}
        <div className="absolute inset-0 rounded-3xl animate-ping opacity-20"
          style={{ background: 'var(--accent)' }} />
      </div>

      <h1 className="text-2xl font-bold text-white mb-2 tracking-tight">Infinite Chats</h1>
      <p className="text-sm mb-8" style={{ color: 'var(--text-muted)' }}>Connect beyond limits.</p>

      {/* Loading dots */}
      <div className="flex gap-2">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="w-2 h-2 rounded-full"
            style={{
              background: 'var(--accent)',
              animation: `pulseDot 1.4s ease-in-out ${i * 0.2}s infinite`,
            }}
          />
        ))}
      </div>
    </div>
  );
}
