# ∞ Infinite Chats
### *Connect beyond limits.*

A production-grade, real-time full-stack chat application built with React 18, Firebase, and TailwindCSS.

---

## 🗂️ Project Structure

```
infinite-chats/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── auth/
│   │   │   └── ProtectedRoute.jsx       # Route guard for auth
│   │   ├── chat/
│   │   │   ├── ChatWindow.jsx           # Main chat area
│   │   │   ├── MessageBubble.jsx        # Individual message with reactions
│   │   │   ├── MessageInput.jsx         # Compose bar with emoji/GIF/file
│   │   │   ├── GifPicker.jsx            # Tenor GIF picker
│   │   │   └── WelcomeScreen.jsx        # Empty state screen
│   │   ├── groups/
│   │   │   └── GroupCreateModal.jsx     # Multi-step group creation
│   │   ├── settings/
│   │   │   └── SettingsPanel.jsx        # Full settings with theme preview
│   │   ├── sidebar/
│   │   │   ├── Sidebar.jsx              # Full sidebar with tabs
│   │   │   └── ConversationItem.jsx     # Conversation list item
│   │   └── ui/
│   │       ├── Avatar.jsx               # Avatar with status dot
│   │       ├── ImageLightbox.jsx        # Full-screen image viewer
│   │       └── LoadingScreen.jsx        # Animated splash screen
│   ├── hooks/                           # (extend here)
│   ├── lib/
│   │   ├── firebase.js                  # Firebase initialization
│   │   ├── authService.js               # Auth operations
│   │   ├── chatService.js               # Conversations & messages
│   │   ├── userService.js               # Profiles, friends, uploads
│   │   └── gifService.js                # Tenor API integration
│   ├── pages/
│   │   ├── LoginPage.jsx
│   │   ├── RegisterPage.jsx
│   │   ├── ProfileSetupPage.jsx
│   │   └── ChatPage.jsx                 # Main app layout
│   ├── store/
│   │   ├── authStore.js                 # Zustand auth state
│   │   ├── chatStore.js                 # Zustand chat state
│   │   └── uiStore.js                   # Zustand UI + theme state
│   ├── styles/
│   │   └── globals.css                  # CSS variables + Tailwind
│   ├── utils/
│   │   └── helpers.js                   # Utilities & formatters
│   ├── App.jsx                          # Root with routing + auth init
│   └── main.jsx                         # Entry point
├── .env                                 # Environment variables (rename from .env.example)
├── firebase.json                        # Firebase hosting config
├── firestore.rules                      # Firestore security rules
├── firestore.indexes.json               # Firestore composite indexes
├── storage.rules                        # Storage security rules
├── tailwind.config.js
├── vite.config.js
└── package.json
```

---

## ⚙️ Prerequisites

Before you begin, make sure you have installed:
- **Node.js** v18 or higher — https://nodejs.org
- **npm** v9 or higher (comes with Node.js)
- **Git** (optional, for cloning) — https://git-scm.com
- A **Firebase project** (already configured — see Firebase section)
- A **Tenor API key** (free) — https://tenor.com/developer/keyregistration

---

## 🚀 Step-by-Step: Run Locally

### Step 1 — Get the project files

Unzip the downloaded `infinite-chats.zip` into a folder of your choice, then open a terminal in that folder:

```bash
cd infinite-chats
```

### Step 2 — Install dependencies

```bash
npm install
```

This installs all packages including React, Firebase, TailwindCSS, Zustand, etc.
Takes about 30–60 seconds.

### Step 3 — Set up environment variables

The `.env` file is already pre-filled with your Firebase config. Open it to verify:

```
VITE_FIREBASE_API_KEY=AIzaSyCD03oRPDmbXuciCCClXYZXQgMHt9byyGM
VITE_FIREBASE_AUTH_DOMAIN=telegram-app-cd720.firebaseapp.com
VITE_FIREBASE_DATABASE_URL=https://telegram-app-cd720-default-rtdb.firebaseio.com
VITE_FIREBASE_PROJECT_ID=telegram-app-cd720
VITE_FIREBASE_STORAGE_BUCKET=telegram-app-cd720.firebasestorage.app
VITE_FIREBASE_MESSAGING_SENDER_ID=161717970897
VITE_FIREBASE_APP_ID=1:161717970897:web:02af6249344449514fa2f0
VITE_FIREBASE_MEASUREMENT_ID=G-HLH5D10X8H

# Optional: Add your Tenor API key for GIF support
VITE_TENOR_API_KEY=your_tenor_key_here
```

> **Tenor API key** (free): Visit https://tenor.com/developer/keyregistration → sign in → register app → copy key → paste above. Without it, GIFs use a demo key with rate limits.

### Step 4 — Start the development server

```bash
npm run dev
```

Open your browser at **http://localhost:3000**

---

## 🔥 Firebase Setup (Required One-Time)

### Step 1 — Enable Authentication

1. Go to https://console.firebase.google.com
2. Open project **telegram-app-cd720**
3. Click **Authentication** → **Get Started**
4. Enable **Email/Password** provider
5. Enable **Google** provider (add your support email)

### Step 2 — Deploy Firestore Security Rules

```bash
# Install Firebase CLI (if not installed)
npm install -g firebase-tools

# Login
firebase login

# Deploy rules + indexes
firebase deploy --only firestore:rules,firestore:indexes
```

Or paste `firestore.rules` manually in Firebase Console → Firestore → Rules tab.

### Step 3 — Deploy Storage Rules

```bash
firebase deploy --only storage
```

Or paste `storage.rules` in Firebase Console → Storage → Rules tab.

### Step 4 — Create Firestore Indexes

The `firestore.indexes.json` file defines required composite indexes. Deploy them:

```bash
firebase deploy --only firestore:indexes
```

Or create manually in Firebase Console → Firestore → Indexes:
- Collection: `conversations` — Fields: `participants` (array) + `createdAt` (desc)
- Collection: `messages` — Fields: `timestamp` (asc)
- Collection: `users` — Fields: `username` (asc)

### Step 5 — Enable Realtime Database

1. Firebase Console → **Realtime Database** → **Create database**
2. Choose location (e.g. us-central1)
3. Start in **test mode** (rules can be tightened later)
4. The URL `https://telegram-app-cd720-default-rtdb.firebaseio.com` is already in your `.env`

---

## 🌐 Deploy to Firebase Hosting

```bash
# Build production bundle
npm run build

# Deploy to Firebase Hosting
firebase deploy --only hosting
```

Your app will be live at: `https://telegram-app-cd720.web.app`

---

## ✨ Features

| Feature | Status |
|---|---|
| Email/Password Auth | ✅ |
| Google OAuth | ✅ |
| Profile setup (name, username, photo, bio) | ✅ |
| Real-time Direct Messaging | ✅ |
| Group Chats (create, invite, manage) | ✅ |
| GIF Picker (Tenor API) | ✅ |
| File & Image Sharing (Firebase Storage) | ✅ |
| Image Lightbox Viewer | ✅ |
| Message Reactions (emoji) | ✅ |
| Reply to Message | ✅ |
| Delete Message (for me / for everyone) | ✅ |
| Typing Indicators | ✅ |
| Online/Offline/DND Status | ✅ |
| Friend Requests System | ✅ |
| User Search (by username) | ✅ |
| Read Receipts (✓ / ✓✓) | ✅ |
| Theme Customization (7 accents) | ✅ |
| Dark / Light / System Mode | ✅ |
| 4 Bubble Styles | ✅ |
| Font Size Control | ✅ |
| Message Density Control | ✅ |
| Emoji Picker | ✅ |
| Unread Message Badges | ✅ |
| Mobile Responsive | ✅ |
| Firebase Security Rules | ✅ |
| Persistent Auth (no re-login on refresh) | ✅ |
| Skeleton Loaders | ✅ |
| Auto-scroll to Latest Message | ✅ |
| Scroll-to-bottom Button | ✅ |
| Settings Panel (Account/Appearance/Privacy/Notifications) | ✅ |

---

## 💡 Suggested Next Improvements

1. **Push Notifications** — Firebase Cloud Messaging (FCM) for mobile notifications
2. **Voice/Video Calls** — WebRTC or Agora.io integration
3. **Message Search** — Full-text search via Algolia or Firestore queries
4. **Scheduled Messages** — Firebase Cloud Functions + cron
5. **Story/Status** — 24-hour disappearing stories
6. **E2E Encryption** — Signal Protocol or client-side AES encryption
7. **Pinned Messages** — Pin important messages in groups
8. **Forward Message** — Forward to other conversations
9. **Polls in Groups** — Voting system via Firestore
10. **Custom Sticker Packs** — Upload and share sticker sets
11. **Bot Framework** — Webhook-based chat bots
12. **Admin Dashboard** — User management, analytics

---

## 🔧 Available Scripts

```bash
npm run dev        # Start dev server at http://localhost:3000
npm run build      # Production build → dist/
npm run preview    # Preview production build locally
npm run lint       # ESLint check
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite 5 |
| Styling | TailwindCSS 3 + CSS Variables |
| State Management | Zustand 4 |
| Routing | React Router v6 |
| Auth | Firebase Authentication |
| Database | Firebase Firestore |
| Real-time Presence | Firebase Realtime Database |
| File Storage | Firebase Storage |
| GIF API | Tenor API v2 |
| Emoji Picker | emoji-picker-react |
| Notifications | react-hot-toast |

---

*Infinite Chats — Connect beyond limits. ∞*
